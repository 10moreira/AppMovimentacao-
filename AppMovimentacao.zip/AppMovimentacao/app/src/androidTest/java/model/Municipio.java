package model;

/**
 * Created by mateus on 28/09/17.
 */
public class Municipio {

        private Integer id;
        private String nome;



public Municipio(){



}


        public Integer getId() {
                return id;
        }

        public void setId(Integer id) {
                this.id = id;
        }

        public String getNome() {
                return nome;
        }

        public void setNome(String nome) {
                this.nome = nome;
        }
}
