package model;

/**
 * Created by mateus on 28/09/17.
 */
public class OrigemDestino {

    Integer origem_destino;
    String descricao;
    String tipo;
    Fazenda fazenda;



}
