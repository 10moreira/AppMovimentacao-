package model;

import java.util.Calendar;

/**
 * Created by mateus on 28/09/17.
 */
public class CategoriaAnimal {

    Integer id;
    String nome;
    Calendar meses_inicial;
    Calendar meses_final;


}
