package model;

import java.util.Calendar;

/**
 * Created by mateus on 28/09/17.
 */
public class CategoriaAnimal {

    private Integer id;
    private String nome;
    private Calendar meses_inicial;
    private Calendar meses_final;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Calendar getMeses_inicial() {
        return meses_inicial;
    }

    public void setMeses_inicial(Calendar meses_inicial) {
        this.meses_inicial = meses_inicial;
    }

    public Calendar getMeses_final() {
        return meses_final;
    }

    public void setMeses_final(Calendar meses_final) {
        this.meses_final = meses_final;
    }
}
