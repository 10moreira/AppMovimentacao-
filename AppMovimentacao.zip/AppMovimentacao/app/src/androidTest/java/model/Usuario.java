package model;

/**
 * Created by mateus on 28/09/17.
 */
public class Usuario {

    Integer id;
    String email;
    String nome;
    Integer fone_ddi;
    Integer fone_area;
    String fonenumero;
    TipoUsuario tipoUsuario;


}
