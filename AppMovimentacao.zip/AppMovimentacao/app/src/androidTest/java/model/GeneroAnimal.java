package model;

/**
 * Created by mateus on 28/09/17.
 */
public class GeneroAnimal {

    Integer id;
    String sexo;
    String descricao;
    CategoriaAnimal categoria_animal;


}
