package model;

/**
 * Created by mateus on 28/09/17.
 */
public class Estoque {

    private Integer id;
    private Long saldo;
    private OrigemDestino origem_destino;
    private GeneroAnimal genero_animal;
    private Fazenda fazenda;


  public Estoque(){

  }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getSaldo() {
        return saldo;
    }

    public void setSaldo(Long saldo) {
        this.saldo = saldo;
    }

    public OrigemDestino getOrigem_destino() {
        return origem_destino;
    }

    public void setOrigem_destino(OrigemDestino origem_destino) {
        this.origem_destino = origem_destino;
    }

    public GeneroAnimal getGenero_animal() {
        return genero_animal;
    }

    public void setGenero_animal(GeneroAnimal genero_animal) {
        this.genero_animal = genero_animal;
    }

    public Fazenda getFazenda() {
        return fazenda;
    }

    public void setFazenda(Fazenda fazenda) {
        this.fazenda = fazenda;
    }
}
