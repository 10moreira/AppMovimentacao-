package model;

/**
 * Created by mateus on 28/09/17.
 */
public class TipoUsuario {

    Integer id;
    String nome;

}
