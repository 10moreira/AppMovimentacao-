package model;

import java.util.Calendar;

/**
 * Created by mateus on 28/09/17.
 */
public class Movimento {

    Calendar data_movimento;
    Integer quantidade;
    Fazenda fazenda;
    GeneroAnimal genero_animal;
    OrigemDestino origem_destino;
    Usuario usuario;


}
