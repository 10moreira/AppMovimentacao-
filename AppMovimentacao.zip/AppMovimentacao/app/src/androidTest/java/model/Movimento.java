package model;

import java.util.Calendar;

/**
 * Created by mateus on 28/09/17.
 */
public class Movimento {

    private Integer id;
    private Calendar data_movimento;
    private Integer quantidade;
    private Fazenda fazenda;
    private GeneroAnimal genero_animal;
    private OrigemDestino origem_destino;
    private Usuario usuario;


    public Movimento() {

    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Calendar getData_movimento() {
        return data_movimento;
    }

    public void setData_movimento(Calendar data_movimento) {
        this.data_movimento = data_movimento;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    public Fazenda getFazenda() {
        return fazenda;
    }

    public void setFazenda(Fazenda fazenda) {
        this.fazenda = fazenda;
    }

    public GeneroAnimal getGenero_animal() {
        return genero_animal;
    }

    public void setGenero_animal(GeneroAnimal genero_animal) {
        this.genero_animal = genero_animal;
    }

    public OrigemDestino getOrigem_destino() {
        return origem_destino;
    }

    public void setOrigem_destino(OrigemDestino origem_destino) {
        this.origem_destino = origem_destino;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}