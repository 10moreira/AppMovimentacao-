package dominio;

/**
 * Created by mateus on 08/10/17.
 */
public class DataModelCategoriaAnimal {

    private static final String DB_NAME = "DBappMovimento.sqlite";
    private static final String TABELA_CATEGORIAANIMAL = "CategoriaAnimal";
    private static final String ID = "id";
    private static final String NOME = "nome";
    private static final String MESINICIAL = "mesinicial";
    private static final String MESESFINAL = "mesesfinal";
    private static final String TIPO_TEXTO = "TEXT";
    private static final String TIPO_DATE = "DATE";
    private static final String TIPO_INTEIRO = "INTEGER";
    private static final String TIPO_INTEIRO_PK = "INTEGER PRIMARY KEY";



    public static String criaTabelaCategoriaAnimal(){
        String query = "CREATE TABLE " + TABELA_CATEGORIAANIMAL;
        query += " (";
        query += ID + " " + TIPO_INTEIRO_PK + ", ";
        query += NOME + " " + TIPO_TEXTO + ", ";
        query += MESINICIAL + " " + TIPO_DATE + ", ";
        query += MESESFINAL + " " + TIPO_DATE + " ";
        query += ")";

        return query;
    }




    public static String getDbName() {
        return DB_NAME;
    }

    public static String getTabelaCategoriaanimal() {
        return TABELA_CATEGORIAANIMAL;
    }

    public static String getID() {
        return ID;
    }

    public static String getNOME() {
        return NOME;
    }

    public static String getMESINICIAL() {
        return MESINICIAL;
    }

    public static String getMESESFINAL() {
        return MESESFINAL;
    }

    public static String getTipoTexto() {
        return TIPO_TEXTO;
    }

    public static String getTipoDate() {
        return TIPO_DATE;
    }

    public static String getTipoInteiro() {
        return TIPO_INTEIRO;
    }

    public static String getTipoInteiroPk() {
        return TIPO_INTEIRO_PK;
    }



}