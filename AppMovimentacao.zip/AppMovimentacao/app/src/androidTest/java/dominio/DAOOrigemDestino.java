package dominio;

import android.content.ContentValues;
import android.content.Context;

import model.Fazenda;
import model.OrigemDestino;

/**
 * Created by mateus on 08/10/17.
 */
public class DAOOrigemDestino {

    DataSourceOrigemDestino dso;
    ContentValues values;



    public DAOOrigemDestino (Context context){
        dso = new DataSourceOrigemDestino(context);
    }


    public boolean SalvarOrigemDestino(OrigemDestino origemdestino){
        boolean retorno = false;

        values = new ContentValues();

        values.put(DataModelOrigemDestino.getDESCRICAO(), origemdestino.getDescricao());
        values.put(DataModelOrigemDestino.getTIPO(), origemdestino.getTipo());
        Fazenda fazenda = new Fazenda();

        values.put(DataModelOrigemDestino.getFAZENDA(), fazenda.getId());


        try{
            dso.persist(values, DataModelOrigemDestino.criaTabelaOrigemDestino());
            retorno = true;
        }catch (Exception e){

        }
        return retorno;

    }


}
