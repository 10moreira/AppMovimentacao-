package dominio;

import android.content.ContentValues;
import android.content.Context;

import model.TipoUsuario;

/**
 * Created by mateus on 09/10/17.
 */
public class DAOTipousuario {

    DataSourceTipousuario dtu;
    ContentValues values;


    public DAOTipousuario (Context context){
        dtu = new DataSourceTipousuario(context);
    }


    public boolean SalvarTipoUsuario(TipoUsuario tipoUsuario){
        boolean retorno = false;

        values = new ContentValues();

        values.put(DataModelTipousuario.getNOME(), tipoUsuario.getNome());

        try{
            dtu.persist(values, DataModelTipousuario.criaTabelaTipoUsuario());
            retorno = true;
        }catch (Exception e){

        }
        return retorno;

    }



}
