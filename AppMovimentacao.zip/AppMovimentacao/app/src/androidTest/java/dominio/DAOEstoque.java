package dominio;

import android.content.ContentValues;
import android.content.Context;

import model.Estoque;
import model.Fazenda;
import model.GeneroAnimal;
import model.OrigemDestino;

/**
 * Created by mateus on 06/10/17.
 */
public class DAOEstoque {

 DataSourceEstoque dse;
 ContentValues values;


    public DAOEstoque (Context context){

        dse = new DataSourceEstoque(context);

    }


    public boolean SalvarEstoque(Estoque estoque){
        boolean retorno = false;

      values = new ContentValues();

      values.put(DataModelEstoque.getSALDO(), estoque.getSaldo());

        OrigemDestino origemdestino = new OrigemDestino();
        values.put(DataModelEstoque.getORIGEMDESTINO(), origemdestino.getOrigem_destino());

        GeneroAnimal generoanimal = new GeneroAnimal();
        values.put(DataModelEstoque.getGENEROANIMAL(), generoanimal.getId());

        Fazenda fazenda = new Fazenda();
        values.put(DataModelEstoque.getFAZENDA(), fazenda.getId());


        try {
            dse.persist(values, DataModelEstoque.getTabelaEstoque());
            retorno = true;
        }catch (Exception e){

        }

            return retorno;

    }
}
