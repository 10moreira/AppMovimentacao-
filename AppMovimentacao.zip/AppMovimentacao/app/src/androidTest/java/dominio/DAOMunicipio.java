package dominio;

import android.content.ContentValues;
import android.content.Context;

import model.Municipio;

/**
 * Created by mateus on 08/10/17.
 */
public class DAOMunicipio {

    DataSourceMunicipio dsm;
    ContentValues values;


    public DAOMunicipio (Context context){
        dsm = new DataSourceMunicipio(context);
    }



    public boolean SalvarMunicipio(Municipio municipio){
        boolean retorno = false;

        values = new ContentValues();

        values.put(DataModelMunicipio.getNOME(), municipio.getNome());


        try{
            dsm.persist(values, DataModelMovimento.criaTabelaMovimento());
            retorno = true;
        }catch (Exception e){

        }
        return retorno;

    }





}
