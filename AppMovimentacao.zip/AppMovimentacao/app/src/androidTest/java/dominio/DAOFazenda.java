package dominio;

import android.content.ContentValues;
import android.content.Context;

import model.Fazenda;
import model.Municipio;

/**
 * Created by mateus on 06/10/17.
 */
public class DAOFazenda {


    DataSourceFazenda df;
    ContentValues values;

        public DAOFazenda (Context context){
            df = new DataSourceFazenda(context);
        }

    public boolean SalvarFazenda(Fazenda fazenda){
        boolean retorno = false;

    values = new ContentValues();

    values.put(DataModelFazenda.getNOMEFAZENDA(), fazenda.getNome());
    values.put(DataModelFazenda.getLOCALIDADE(), fazenda.getLocalidade());
    values.put(DataModelFazenda.getLATITUDE(), fazenda.getLatitude());
    values.put(DataModelFazenda.getLONGITUDE(), fazenda.getLongitude());
        Municipio  municipio = new Municipio();
    values.put(DataModelFazenda.getMUNICIPIO(), municipio.getId());

    try{
        df.persist(values, DataModelFazenda.getTabelaFazenda());
        retorno = true;
    }catch (Exception e){

    }
    return retorno;

    }

}
