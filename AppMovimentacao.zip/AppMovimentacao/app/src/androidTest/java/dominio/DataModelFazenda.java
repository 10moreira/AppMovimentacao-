package dominio;

/**
 * Created by mateus on 06/10/17.
 */
public class DataModelFazenda {


    private static final String DB_NAME = "DBappMovimento.sqlite";
    private static final String TABELA_FAZENDA = "fazenda";
    private static final String ID = "id";
    private static final String NOMEFAZENDA = "nome";
    private static final String LOCALIDADE = "localidade";
    private static final String LATITUDE = "latitude";
    private static final String LONGITUDE = "longitude";
    private static final String MUNICIPIO = "municipio";
    private static final String TIPO_TEXTO = "TEXT";
    private static final String TIPO_FLOAT = "FLOAT";
    private static final String TIPO_INTEIRO = "INTEGER";
    private static final String TIPO_INTEIRO_PK = "INTEGER PRIMARY KEY";
    private static final String TIPO_INTEIRO_FK = "INTEGER FOREING KEY";



    public static String criaTabelaFazenda(){
        String query = "CREATE TABLE " + TABELA_FAZENDA;
        query += " (";
        query += ID + " " + TIPO_INTEIRO_PK + ", ";
        query += NOMEFAZENDA + " " + TIPO_TEXTO + ", ";
        query += LOCALIDADE + " " + TIPO_FLOAT + ", ";
        query += LATITUDE + " " + TIPO_FLOAT + ", ";
        query += LONGITUDE + " " + TIPO_FLOAT + ", ";
        query += MUNICIPIO + " " + TIPO_INTEIRO_FK + " ";
        query += ")";

        return query;
    }



    public static String getDbName() {
        return DB_NAME;
    }

    public static String getTabelaFazenda() {
        return TABELA_FAZENDA;
    }

    public static String getID() {
        return ID;
    }

    public static String getNOMEFAZENDA() {
        return NOMEFAZENDA;
    }

    public static String getLOCALIDADE() {
        return LOCALIDADE;
    }

    public static String getLATITUDE() {
        return LATITUDE;
    }

    public static String getLONGITUDE() {
        return LONGITUDE;
    }

    public static String getMUNICIPIO() {
        return MUNICIPIO;
    }

    public static String getTipoTexto() {
        return TIPO_TEXTO;
    }

    public static String getTipoFloat() {
        return TIPO_FLOAT;
    }

    public static String getTipoInteiro() {
        return TIPO_INTEIRO;
    }

    public static String getTipoInteiroPk() {
        return TIPO_INTEIRO_PK;
    }

    public static String getTipoInteiroFk() {
        return TIPO_INTEIRO_FK;
    }


}
