package dominio;

/**
 * Created by mateus on 09/10/17.
 */
public class DataModelTipousuario {

    private static final String DB_NAME = "DBappMovimento.sqlite";
    private static final String TABELA_TIPOUSUARIO = "tipousuario";
    private static final String ID = "id";
    private static final String NOME = "nome";
    private static final String TIPO_INTEIRO = "INTEGER";
    private static final String TIPO_TEXTO = "TEXT";
    private static final String TIPO_INTEIRO_PK = "INTEGER PRIMARY KEY";




    public static String criaTabelaTipoUsuario(){
        String query = "CREATE TABLE " + TABELA_TIPOUSUARIO;
        query += " (";
        query += ID + " " + TIPO_INTEIRO_PK + ", ";
        query += NOME + " " + TIPO_TEXTO + ", ";
        query += ")";

        return query;
    }


    public static String getDbName() {
        return DB_NAME;
    }

    public static String getTabelaTipousuario() {
        return TABELA_TIPOUSUARIO;
    }

    public static String getID() {
        return ID;
    }

    public static String getNOME() {
        return NOME;
    }

    public static String getTipoInteiro() {
        return TIPO_INTEIRO;
    }

    public static String getTipoTexto() {
        return TIPO_TEXTO;
    }

    public static String getTipoInteiroPk() {
        return TIPO_INTEIRO_PK;
    }
}
