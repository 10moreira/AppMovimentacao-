package dominio;

import android.content.ContentValues;
import android.content.Context;

import model.CategoriaAnimal;
import model.GeneroAnimal;

/**
 * Created by mateus on 07/10/17.
 */
public class DAOGeneronimal {

    DataSourceGeneroAnimal dsga;
    ContentValues values;



    public DAOGeneronimal (Context context){
        dsga = new DataSourceGeneroAnimal(context);
    }


    public boolean SalvarGeneroAnimal(GeneroAnimal generoanimal){
        boolean retorno = false;

        values = new ContentValues();

        values.put(DataModelGeneroAnimal.getSEXO(), generoanimal.getSexo());
        values.put(DataModelGeneroAnimal.getDESCRICAO(), generoanimal.getDescricao());




        CategoriaAnimal categoriaanimal = new CategoriaAnimal();

        values.put(DataModelGeneroAnimal.getCATEGORIAANIMAL(), categoriaanimal.getId());

        try{
            dsga.persist(values, DataModelGeneroAnimal.criaTabelaGeneroAnimal());
            retorno = true;
        }catch (Exception e){

        }
        return retorno;

    }

}

