package dominio;

import android.content.ContentValues;
import android.content.Context;

import model.TipoUsuario;
import model.Usuario;

/**
 * Created by mateus on 09/10/17.
 */
public class DAOusuario {

    DataSourceUsuario dsu;
    ContentValues values;


    public DAOusuario (Context context){
        dsu = new DataSourceUsuario(context);
    }

    public boolean SalvarUsuario(Usuario usuario){
        boolean retorno = false;

        values = new ContentValues();

        values.put(DataModelUsuario.getNOME(), usuario.getNome());
        values.put(DataModelUsuario.getEMAIL(), usuario.getEmail());
        values.put(DataModelUsuario.getFONEDDI(), usuario.getFone_ddi());
        values.put(DataModelUsuario.getFONEAREA(), usuario.getFone_area());
        values.put(DataModelUsuario.getFONENUMERO(), usuario.getFonenumero());

        TipoUsuario tipousuario =  new TipoUsuario();
        values.put(DataModelUsuario.getTIPOUSUARIO(), tipousuario.getId());


        try{
            dsu.persist(values, DataModelUsuario.criaTabelaUsuario());
            retorno = true;
        }catch (Exception e){

        }
        return retorno;

    }



}
