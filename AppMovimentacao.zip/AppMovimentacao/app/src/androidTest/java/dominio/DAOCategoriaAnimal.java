package dominio;

import android.content.ContentValues;
import android.content.Context;

import java.util.Calendar;
import java.util.GregorianCalendar;

import model.CategoriaAnimal;

/**
 * Created by mateus on 08/10/17.
 */
public class DAOCategoriaAnimal {

    DataSourceCategoriaAnimal dsc;
    ContentValues values;


    public DAOCategoriaAnimal (Context context){

        dsc = new DataSourceCategoriaAnimal(context);

    }



    public boolean SalvarCategoriaAnimal(CategoriaAnimal categoriaalnimal){
        boolean retorno = false;

        values = new ContentValues();

        values.put(DataModelCategoriaAnimal.getNOME(), categoriaalnimal.getNome());

        Calendar mesinicial =  new GregorianCalendar();
        values.put(DataModelCategoriaAnimal.getMESINICIAL(), mesinicial.toString());

        Calendar mesfinal = new GregorianCalendar();
        values.put(DataModelCategoriaAnimal.getMESESFINAL(), mesfinal.toString());


        try {
            dsc.persist(values, DataModelCategoriaAnimal.getTabelaCategoriaanimal());
            retorno = true;
        }catch (Exception e){

        }

        return retorno;

    }



}
