package dominio;

/**
 * Created by mateus on 06/10/17.
 */
public class DataModelEstoque {


    private static final String DB_NAME = "DBappMovimento.sqlite";
    private static final String TABELA_ESTOQUE = "estoque";
    private static final String ID = "id";
    private static final String SALDO = "saldo";
    private static final String ORIGEMDESTINO = "origemDestino";
    private static final String GENEROANIMAL = "generoAnimal";
    private static final String FAZENDA = "fazenda";
    private static final String TIPO_TEXTO = "TEXT";
    private static final String TIPO_FLOAT = "FLOAT";
    private static final String TIPO_INTEIRO = "INTEGER";
    private static final String TIPO_INTEIRO_PK = "INTEGER PRIMARY KEY";
    private static final String TIPO_INTEIRO_FK = "INTEGER FOREING KEY";



    public static String criaTabelaEstoque(){
        String query = "CREATE TABLE " + TABELA_ESTOQUE;
        query += " (";
        query += ID + " " + TIPO_INTEIRO_PK + ", ";
        query += SALDO + " " + TIPO_FLOAT + ", ";
        query += ORIGEMDESTINO + GENEROANIMAL + FAZENDA + " " + TIPO_INTEIRO_FK + " ";
        query += ")";

        return query;
    }



    public static String getDbName() {
        return DB_NAME;
    }

    public static String getTabelaEstoque() {
        return TABELA_ESTOQUE;
    }

    public static String getID() {
        return ID;
    }

    public static String getSALDO() {
        return SALDO;
    }

    public static String getORIGEMDESTINO() {
        return ORIGEMDESTINO;
    }

    public static String getGENEROANIMAL() {
        return GENEROANIMAL;
    }

    public static String getFAZENDA() {
        return FAZENDA;
    }

    public static String getTipoTexto() {
        return TIPO_TEXTO;
    }

    public static String getTipoFloat() {
        return TIPO_FLOAT;
    }

    public static String getTipoInteiro() {
        return TIPO_INTEIRO;
    }

    public static String getTipoInteiroPk() {
        return TIPO_INTEIRO_PK;
    }

    public static String getTipoInteiroFk() {
        return TIPO_INTEIRO_FK;
    }

}
