package dominio;

/**
 * Created by mateus on 08/10/17.
 */
public class DataModelMovimento {

    private static final String DB_NAME = "DBappMovimento.sqlite";
    private static final String TABELA_MOVIMENTO = "movimento";
    private static final String ID = "id";
    private static final String DATAMOVIMENTO = "datamovimento";
    private static final String QUANTIDADE = "quantidade";
    private static final String FAZENDA = "fazenda";
    private static final String GENEROANIMAL = "generoanimal";
    private static final String ORIGEMDESTINO = "origemdestino";
    private static final String USUARIO = "usuario";
    private static final String TIPO_CALENDAR = "DATE";
    private static final String TIPO_FLOAT = "FLOAT";
    private static final String TIPO_INTEIRO = "INTEGER";
    private static final String TIPO_INTEIRO_PK = "INTEGER PRIMARY KEY";
    private static final String TIPO_INTEIRO_FK = "INTEGER FOREING KEY";



    public static String criaTabelaMovimento(){
        String query = "CREATE TABLE " + TABELA_MOVIMENTO;
        query += " (";
        query += ID + " " + TIPO_INTEIRO_PK + ", ";
        query += DATAMOVIMENTO + " " + TIPO_CALENDAR + ", ";
        query += QUANTIDADE + " " + TIPO_FLOAT + ", ";
        query += FAZENDA + " " + TIPO_INTEIRO_FK + ", ";
        query += GENEROANIMAL + " " + TIPO_INTEIRO_FK + ", ";
        query += ORIGEMDESTINO + " " + TIPO_INTEIRO_FK + ", ";
        query += USUARIO + " " + TIPO_INTEIRO_FK + " ";
        query += ")";

        return query;
    }


    public static String getDbName() {
        return DB_NAME;
    }

    public static String getTabelaMovimento() {
        return TABELA_MOVIMENTO;
    }

    public static String getID() {
        return ID;
    }

    public static String getDATAMOVIMENTO() {
        return DATAMOVIMENTO;
    }

    public static String getQUANTIDADE() {
        return QUANTIDADE;
    }

    public static String getFAZENDA() {
        return FAZENDA;
    }

    public static String getGENEROANIMAL() {
        return GENEROANIMAL;
    }

    public static String getORIGEMDESTINO() {
        return ORIGEMDESTINO;
    }

    public static String getUSUARIO() {
        return USUARIO;
    }

    public static String getTipoCalendar() {
        return TIPO_CALENDAR;
    }

    public static String getTipoFloat() {
        return TIPO_FLOAT;
    }

    public static String getTipoInteiro() {
        return TIPO_INTEIRO;
    }

    public static String getTipoInteiroPk() {
        return TIPO_INTEIRO_PK;
    }

    public static String getTipoInteiroFk() {
        return TIPO_INTEIRO_FK;
    }


}
