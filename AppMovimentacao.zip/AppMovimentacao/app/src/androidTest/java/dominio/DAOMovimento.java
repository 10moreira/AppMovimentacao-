package dominio;

import android.content.ContentValues;
import android.content.Context;

import model.Fazenda;
import model.GeneroAnimal;
import model.Movimento;
import model.OrigemDestino;
import model.Usuario;

/**
 * Created by mateus on 08/10/17.
 */
public class DAOMovimento {

    DataSourceMovimento dsm;
    ContentValues values;


    public DAOMovimento (Context context){
        dsm = new DataSourceMovimento(context);
    }


    public boolean SalvarMovimento(Movimento movimento){
        boolean retorno = false;

        values = new ContentValues();


        java.util.Calendar datamovimento = new java.util.GregorianCalendar();
        values.put(DataModelMovimento.getDATAMOVIMENTO(), datamovimento.toString());

        values.put(DataModelMovimento.getQUANTIDADE(), movimento.getQuantidade());

        Fazenda fazenda =  new Fazenda();
        values.put(DataModelMovimento.getFAZENDA(), fazenda.getId());

        GeneroAnimal generoanimal = new GeneroAnimal();
        values.put(DataModelMovimento.getGENEROANIMAL(), generoanimal.getId());

        OrigemDestino origemdestino = new OrigemDestino();
        values.put(DataModelMovimento.getORIGEMDESTINO(), origemdestino.getOrigem_destino());


        Usuario usuario = new Usuario();
        values.put(DataModelMovimento.getUSUARIO(), usuario.getId());


        try{
            dsm.persist(values, DataModelMovimento.criaTabelaMovimento());
            retorno = true;
        }catch (Exception e){

        }
        return retorno;

    }


}
