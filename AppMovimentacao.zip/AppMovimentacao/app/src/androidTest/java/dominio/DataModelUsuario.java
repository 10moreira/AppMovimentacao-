package dominio;

/**
 * Created by mateus on 09/10/17.
 */
public class DataModelUsuario {

    private static final String DB_NAME = "DBappMovimento.sqlite";
    private static final String TABELA_USUARIO = "usuario";
    private static final String ID = "id";
    private static final String NOME = "nome";
    private static final String EMAIL = "email";
    private static final String FONEDDI = "foneddi";
    private static final String FONEAREA = "fonearea";
    private static final String FONENUMERO = "fonenumero";
    private static final String TIPOUSUARIO = "tipousuario";
    private static final String TIPO_INTEIRO = "INTEGER";
    private static final String TIPO_TEXTO = "TEXT";
    private static final String TIPO_INTEIRO_PK = "INTEGER PRIMARY KEY";
    private static final String TIPO_INTEIRO_FK = "INTEGER FOREING KEY";


    public static String criaTabelaUsuario(){
        String query = "CREATE TABLE " + TABELA_USUARIO;
        query += " (";
        query += ID + " " + TIPO_INTEIRO_PK + ", ";
        query += NOME + " " + TIPO_TEXTO + ", ";
        query += EMAIL + " " + TIPO_TEXTO + ", ";
        query += FONEDDI + " " + TIPO_INTEIRO + ", ";
        query += FONEAREA + " " + TIPO_INTEIRO + ", ";
        query += FONENUMERO + " " + TIPO_TEXTO + ", ";
        query += TIPOUSUARIO + " " + TIPO_INTEIRO_FK + ", ";
        query += ")";

        return query;
    }


    public static String getDbName() {
        return DB_NAME;
    }

    public static String getTabelaUsuario() {
        return TABELA_USUARIO;
    }

    public static String getID() {
        return ID;
    }

    public static String getNOME() {
        return NOME;
    }

    public static String getEMAIL() {
        return EMAIL;
    }

    public static String getFONEDDI() {
        return FONEDDI;
    }

    public static String getFONEAREA() {
        return FONEAREA;
    }

    public static String getFONENUMERO() {
        return FONENUMERO;
    }

    public static String getTIPOUSUARIO() {
        return TIPOUSUARIO;
    }

    public static String getTipoInteiro() {
        return TIPO_INTEIRO;
    }

    public static String getTipoTexto() {
        return TIPO_TEXTO;
    }

    public static String getTipoInteiroPk() {
        return TIPO_INTEIRO_PK;
    }

    public static String getTipoInteiroFk() {
        return TIPO_INTEIRO_FK;
    }
}
