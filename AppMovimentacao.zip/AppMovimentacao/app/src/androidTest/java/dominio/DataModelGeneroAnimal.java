package dominio;

/**
 * Created by mateus on 07/10/17.
 */
public class DataModelGeneroAnimal {

    private static final String DB_NAME = "DBappMovimento.sqlite";
    private static final String TABELA_GENEROANIMAL = "generoanimal";
    private static final String ID = "id";
    private static final String SEXO = "sexo";
    private static final String DESCRICAO = "descricao";
    private static final String CATEGORIAANIMAL = "categoriaanimal";
    private static final String TIPO_TEXTO = "TEXT";
    private static final String TIPO_INTEIRO = "INTEGER";
    private static final String TIPO_INTEIRO_PK = "INTEGER PRIMARY KEY";
    private static final String TIPO_INTEIRO_FK = "INTEGER FOREING KEY";





    public static String criaTabelaGeneroAnimal(){
        String query = "CREATE TABLE " + TABELA_GENEROANIMAL;
        query += " (";
        query += ID + " " + TIPO_INTEIRO_PK + ", ";
        query += SEXO + " " + TIPO_TEXTO + ", ";
        query += DESCRICAO + " " + TIPO_TEXTO + ", ";
        query += CATEGORIAANIMAL + " " + TIPO_INTEIRO_FK + ", ";
        query += ")";

        return query;
    }




    public static String getDbName() {
        return DB_NAME;
    }

    public static String getTabelaGeneroanimal() {
        return TABELA_GENEROANIMAL;
    }

    public static String getID() {
        return ID;
    }

    public static String getSEXO() {
        return SEXO;
    }

    public static String getDESCRICAO() {
        return DESCRICAO;
    }

    public static String getCATEGORIAANIMAL() {
        return CATEGORIAANIMAL;
    }

    public static String getTipoTexto() {
        return TIPO_TEXTO;
    }

    public static String getTipoInteiro() {
        return TIPO_INTEIRO;
    }

    public static String getTipoInteiroPk() {
        return TIPO_INTEIRO_PK;
    }

    public static String getTipoInteiroFk() {
        return TIPO_INTEIRO_FK;
    }

}
