package dominio;

/**
 * Created by mateus on 08/10/17.
 */
public class DataModelOrigemDestino {


    private static final String DB_NAME = "DBappMovimento.sqlite";
    private static final String TABELA_ORIGEMDESTINO = "origemDestino";
    private static final String ID = "id";
    private static final String DESCRICAO = "descricao";
    private static final String TIPO = "tipo";
    private static final String FAZENDA = "fazenda";
    private static final String TIPO_INTEIRO = "INTEGER";
    private static final String TIPO_TEXTO = "TEXT";
    private static final String TIPO_INTEIRO_PK = "INTEGER PRIMARY KEY";
    private static final String TIPO_INTEIRO_FK = "INTEGER FOREING KEY";


    public static String criaTabelaOrigemDestino(){
        String query = "CREATE TABLE " + TABELA_ORIGEMDESTINO;
        query += " (";
        query += ID + " " + TIPO_INTEIRO_PK + ", ";
        query += DESCRICAO + " " + TIPO_TEXTO + ", ";
        query += TIPO + " " + TIPO_TEXTO + ", ";
        query += FAZENDA + " " + TIPO_INTEIRO_FK + " ";
        query += ")";

        return query;
    }



    public static String getDbName() {
        return DB_NAME;
    }

    public static String getTabelaOrigemdestino() {
        return TABELA_ORIGEMDESTINO;
    }

    public static String getID() {
        return ID;
    }

    public static String getDESCRICAO() {
        return DESCRICAO;
    }

    public static String getTIPO() {
        return TIPO;
    }

    public static String getFAZENDA() {
        return FAZENDA;
    }

    public static String getTipoInteiro() {
        return TIPO_INTEIRO;
    }

    public static String getTipoTexto() {
        return TIPO_TEXTO;
    }

    public static String getTipoInteiroPk() {
        return TIPO_INTEIRO_PK;
    }

    public static String getTipoInteiroFk() {
        return TIPO_INTEIRO_FK;
    }



}
