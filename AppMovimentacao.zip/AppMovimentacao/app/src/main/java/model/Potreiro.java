package model;

import java.io.Serializable;

/**
 * Created by mateus on 24/11/17.
 */
public class Potreiro implements Serializable {

    private Integer id;
    private String nomePotreiro;
    private String tamanhopotreiro;


    public Potreiro(){

    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNomePotreiro() {
        return nomePotreiro;
    }

    public void setNomePotreiro(String nomePotreiro) {
        this.nomePotreiro = nomePotreiro;
    }

    public String getTamanhopotreiro() {
        return tamanhopotreiro;
    }

    public void setTamanhopotreiro(String tamanhopotreiro) {
        this.tamanhopotreiro = tamanhopotreiro;
    }
}
