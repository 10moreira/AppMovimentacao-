package model;

/**
 * Created by mateus on 28/09/17.
 */
public class CategoriaAnimal {

    private Integer id;
    private String nome;
    private String meses_inicial;
    private String meses_final;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMeses_inicial() {
        return meses_inicial;
    }

    public void setMeses_inicial(String meses_inicial) {
        this.meses_inicial = meses_inicial;
    }

    public String getMeses_final() {
        return meses_final;
    }

    public void setMeses_final(String meses_final) {
        this.meses_final = meses_final;
    }
}