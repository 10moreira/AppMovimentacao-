package model;

/**
 * Created by mateus on 28/09/17.
 */
public class OrigemDestino {

    private Integer id;
    private Integer origem_destino;
    private String descricao;
    private String tipo;
    private Fazenda fazenda;



    public OrigemDestino(){

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrigem_destino() {
        return origem_destino;
    }

    public void setOrigem_destino(Integer origem_destino) {
        this.origem_destino = origem_destino;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Fazenda getFazenda() {
        return fazenda;
    }

    public void setFazenda(Fazenda fazenda) {
        this.fazenda = fazenda;
    }
}
