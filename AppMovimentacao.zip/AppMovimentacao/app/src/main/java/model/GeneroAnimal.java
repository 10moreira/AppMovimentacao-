
/*
package model;

/**
 * Created by mateus on 28/09/17.
 */

/*
public class GeneroAnimal {

    private Integer id;
    private String sexo;
    private String descricao;
   // private CategoriaAnimal categoria_animal;


    public  GeneroAnimal(){

    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /*
    public CategoriaAnimal getCategoria_animal() {
        return categoria_animal;
    }

    public void setCategoria_animal(CategoriaAnimal categoria_animal) {
        this.categoria_animal = categoria_animal;
    }

}

*/
