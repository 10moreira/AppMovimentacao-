package model;

import java.io.Serializable;

/**
 * Created by mateus on 28/09/17.
 */
public class Estoque implements Serializable {

    private Integer id;
    private Long saldo;
    private String origem;
    private String destino;
    private Integer numeroAnimais;
    private Long areaCriacao;
    private String genero_animal;
    private Fazenda fazenda;


   public Estoque(){

  }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getSaldo() {
        return saldo;
    }

    public void setSaldo(Long saldo) {
        this.saldo = saldo;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public Integer getNumeroAnimais() {
        return numeroAnimais;
    }

    public void setNumeroAnimais(Integer numeroAnimais) {
        this.numeroAnimais = numeroAnimais;
    }

    public Long getAreaCriacao() {
        return areaCriacao;
    }

    public void setAreaCriacao(Long areaCriacao) {
        this.areaCriacao = areaCriacao;
    }

    public String getGenero_animal() {
        return genero_animal;
    }

    public void setGenero_animal(String genero_animal) {
        this.genero_animal = genero_animal;
    }

    public Fazenda getFazenda() {
        return fazenda;
    }

    public void setFazenda(Fazenda fazenda) {
        this.fazenda = fazenda;
    }
}
