package model;

/**
 * Created by mateus on 28/09/17.
 */
public class Estoque {

    private Integer id;
    private Long saldo;
    private String origem_destino;
    private String genero_animal;
    private String fazenda;


  public Estoque(){

  }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getSaldo() {
        return saldo;
    }

    public void setSaldo(Long saldo) {
        this.saldo = saldo;
    }

    public String getOrigem_destino() {
        return origem_destino;
    }

    public void setOrigem_destino(String origem_destino) {
        this.origem_destino = origem_destino;
    }

    public String getGenero_animal() {
        return genero_animal;
    }

    public void setGenero_animal(String genero_animal) {
        this.genero_animal = genero_animal;
    }

    public String getFazenda() {
        return fazenda;
    }

    public void setFazenda(String fazenda) {
        this.fazenda = fazenda;
    }


}
