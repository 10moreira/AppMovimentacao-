package model;

/**
 * Created by mateus on 28/09/17.
 */
public class Usuario {

    private Integer id;
    private String email;
    private String nome;
    private Integer fone_ddi;
    private Integer fone_area;
    private String fonenumero;
    private TipoUsuario tipoUsuario;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getFone_ddi() {
        return fone_ddi;
    }

    public void setFone_ddi(Integer fone_ddi) {
        this.fone_ddi = fone_ddi;
    }

    public Integer getFone_area() {
        return fone_area;
    }

    public void setFone_area(Integer fone_area) {
        this.fone_area = fone_area;
    }

    public String getFonenumero() {
        return fonenumero;
    }

    public void setFonenumero(String fonenumero) {
        this.fonenumero = fonenumero;
    }

    public TipoUsuario getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(TipoUsuario tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
}
