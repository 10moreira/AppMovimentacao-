package model;

import java.io.Serializable;

/**
 * Created by mateus on 28/09/17.
 */
public class Usuario implements Serializable {

    private Integer id;
    private String email;
    private String nome;
    private String fone_ddi;
    private String fone_area;
    private String fonenumero;
    private String tipoUsuario;


    public void Usuario(){

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFonenumero() {
        return fonenumero;
    }

    public void setFonenumero(String fonenumero) {
        this.fonenumero = fonenumero;
    }

    public String getFone_ddi() {
        return fone_ddi;
    }

    public void setFone_ddi(String fone_ddi) {
        this.fone_ddi = fone_ddi;
    }

    public String getFone_area() {
        return fone_area;
    }

    public void setFone_area(String fone_area) {
        this.fone_area = fone_area;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
}
