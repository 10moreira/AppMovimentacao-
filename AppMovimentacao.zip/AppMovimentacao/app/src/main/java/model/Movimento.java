package model;

import java.io.Serializable;

/**
 * Created by mateus on 28/09/17.
 */
public class Movimento implements Serializable {

    private Integer id;
    private String data_movimento;
    private String quantidade;
    private String descricao;
    private String tipo;
    private String origem;
    private String destino;
    private String categoriaanimal;

    public Movimento() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getData_movimento() {
        return data_movimento;
    }

    public void setData_movimento(String data_movimento) {
        this.data_movimento = data_movimento;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public String getCategoriaanimal() {
        return categoriaanimal;
    }

    public void setCategoriaanimal(String categoriaanimal) {
        this.categoriaanimal = categoriaanimal;
    }

    @Override
    public String toString(){
        return tipo;
    }

}