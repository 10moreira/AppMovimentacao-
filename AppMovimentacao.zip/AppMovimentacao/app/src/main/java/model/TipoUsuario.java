package model;

import java.io.Serializable;

/**
 * Created by mateus on 28/09/17.
 */
public class TipoUsuario implements Serializable {

    private Integer id;
    private String nome;

    public TipoUsuario(){

    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
