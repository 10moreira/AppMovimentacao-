package view.activities;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import dao.helper.DatabaseOpenHelper;
import dao.modelDao.CategoriaAnimalDAO;
import mateusmoreira.appmovimentacao.R;

public class MainCategoriaAnimaisListActivity extends Activity implements View.OnClickListener {

    private DatabaseOpenHelper helper;
    private ListView listViewcategoria;
    private ArrayAdapter<String> adpcategoria;
    private DatabaseOpenHelper database;
    private SQLiteDatabase conn;
    private CategoriaAnimalDAO categoriaAnimalDAO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_categoria_animais_list);

        listViewcategoria = (ListView) findViewById(R.id.listViewcategoria);


        database = new DatabaseOpenHelper(this);
        conn = database.getReadableDatabase();


        categoriaAnimalDAO = new CategoriaAnimalDAO(getApplicationContext());

        adpcategoria = categoriaAnimalDAO.buscacategorias(this);

        listViewcategoria.setAdapter(adpcategoria);


    }

    @Override
    public void onClick(View view) {

    }
}
