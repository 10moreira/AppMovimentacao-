package view.activities;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import dao.helper.DatabaseOpenHelper;
import dao.modelDao.MovimentoDAO;
import mateusmoreira.appmovimentacao.R;

public class MovimentacaoListActivity extends Activity implements View.OnClickListener {

    private DatabaseOpenHelper helper;
    private ListView listViewMovimentacao;
    private ArrayAdapter<String> adpMovimento;
    private DatabaseOpenHelper database;
    private SQLiteDatabase conn;
    private MovimentoDAO movimentodao;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movimentacao_list);

        listViewMovimentacao = (ListView) findViewById(R.id.listViewMovimentacao);


        database = new DatabaseOpenHelper(this);
        conn = database.getReadableDatabase();


        movimentodao = new MovimentoDAO(getApplicationContext());

        adpMovimento = movimentodao.buscamovimentos(this);

        listViewMovimentacao.setAdapter(adpMovimento);

    }


    @Override
    public void onClick(View view) {

    }
}

