
package view.activities;

/*
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import dao.modelDao.TipoUsuarioDAO;
import mateusmoreira.appmovimentacao.R;
import model.TipoUsuario;

public class TipoUsuarioActivity extends AppCompatActivity implements View.OnClickListener {

    private TipoUsuarioDAO tipousuarioDAO;
    private TipoUsuario tipousuario;
    //private Integer codigo = -1;
    private EditText editTexttipousuario;
    private Button buttonsalvar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tipo_usuario);

        editTexttipousuario = (EditText) findViewById(R.id.editTexttipousuario);
        buttonsalvar = (Button) findViewById(R.id.buttonsalvar);

        buttonsalvar.setOnClickListener(this);

        }
            public void onClick(View view) {

                switch (view.getId()) {
                    case R.id.buttonsalvar:
                        TipoUsuario tipousuario = new TipoUsuario();
                        tipousuario.setNome(editTexttipousuario.getText().toString());

                        TipoUsuarioDAO tipodao = new TipoUsuarioDAO(getApplicationContext());

                        if(tipodao.insert(tipousuario)){
                            Toast.makeText(getApplication(), "Tipo de usuario cadastrado com sucesso!!", Toast.LENGTH_LONG).show();
                            //startActivity(new Intent(this, TipoUsuarioActivity.class));
                            finish();
                        }else{
                            Toast.makeText(getApplication(), "erro ao gravar tipo de ususario", Toast.LENGTH_LONG).show();
                        }
                        break;
                }


            }
}
*/