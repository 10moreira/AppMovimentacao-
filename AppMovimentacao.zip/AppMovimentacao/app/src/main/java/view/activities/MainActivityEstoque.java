package view.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import dao.modelDao.EstoqueDAO;
import mateusmoreira.appmovimentacao.R;
import model.Estoque;

public class MainActivityEstoque  extends AppCompatActivity implements View.OnClickListener {

    EditText editTextSaldo, editText2NrodeAnimais, editText3areaCriacao;
    Spinner spinnerOrigem, spinnerDestino, spinner3Generoanimal, spinnerPropriedade;
    Button button4ok;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_estoque);


        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(
                this, R.array.campos, android.R.layout.simple_spinner_item);
        spinnerOrigem = (Spinner) findViewById(R.id.spinnerOrigem);
        spinnerOrigem.setAdapter(adapter1);



        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(
                this, R.array.campos, android.R.layout.simple_spinner_item);
        spinnerDestino = (Spinner) findViewById(R.id.spinnerDestino);
        spinnerDestino.setAdapter(adapter2);

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(
                this, R.array.tipoAnimal, android.R.layout.simple_spinner_item);
        spinner3Generoanimal = (Spinner) findViewById(R.id.spinner3Generoanimal);
        spinner3Generoanimal.setAdapter(adapter3);

        editText2NrodeAnimais = (EditText) findViewById(R.id.editText2NrodeAnimais);
        editTextSaldo = (EditText) findViewById(R.id.editTextSaldo);
        editText3areaCriacao = (EditText) findViewById(R.id.editText3areaCriacao);

        spinnerOrigem = (Spinner) findViewById(R.id.spinnerOrigem);
        spinnerDestino = (Spinner) findViewById(R.id.spinnerDestino);
        spinner3Generoanimal = (Spinner) findViewById(R.id.spinner3Generoanimal);

        button4ok = (Button) findViewById(R.id.button4ok);




    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.button4ok:

                Estoque estoque = new Estoque();

                estoque.setSaldo(editTextSaldo.getText().toString());
                estoque.setNumeroAnimais(editText2NrodeAnimais.getText().toString());
                estoque.setAreaCriacao(editText3areaCriacao.getText().toString());
                estoque.setOrigem(spinnerOrigem.getSelectedItem().toString());
                estoque.setDestino(spinnerDestino.getSelectedItem().toString());
                estoque.setGenero_animal(spinner3Generoanimal.getSelectedItem().toString());
                //estoque.setFazenda(spinnerPropriedade.getSelectedItem().toString());

                EstoqueDAO estoqueDAO = new EstoqueDAO(getApplicationContext());


                if(estoqueDAO.insert(estoque)){
                    Toast.makeText(getApplication(), "Estoque registrado!!", Toast.LENGTH_LONG).show();
                    finish();

                }else{
                    Toast.makeText(getApplication(), "erro ao registrar estoque!!", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    public void listaestoques(View view){
        startActivity(new Intent(this, MainEstoqueListActivity.class));
    }

}
