
package view.activities;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import dao.modelDao.UsuarioDAO;
import mateusmoreira.appmovimentacao.R;
import model.Usuario;


public class MainActivityUsuario extends AppCompatActivity implements View.OnClickListener {

    Spinner spinnerusuario;
    EditText editTextnome, editTextemail, editTextddd, editTextdddarea, editTextfone;
    Button buttonok;
    Button buttonusuario;
    //TipoUsuario tipousuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_usuario);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        //chama a Strings.xml com a lista de municipios
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(
                this, R.array.tipousuario, android.R.layout.simple_spinner_item);
        spinnerusuario = (Spinner) findViewById(R.id.spinnerusuario);
        spinnerusuario.setAdapter(adapter1);

        editTextnome = (EditText) findViewById(R.id.editTextnome);
        editTextemail = (EditText) findViewById(R.id.editTextemail);
        editTextdddarea = (EditText) findViewById(R.id.editTextdddarea);
        editTextddd = (EditText) findViewById(R.id.editTextddd);
        editTextfone = (EditText) findViewById(R.id.editTextfone);

        spinnerusuario = (Spinner) findViewById(R.id.spinnerusuario);

        buttonok = (Button) findViewById(R.id.buttonok);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);

        buttonok.setOnClickListener(this);
    }


    public void onClick(View view){
            salvarUsuario(view);
    }

  public void salvarUsuario(View view){

        switch (view.getId()){
            case R.id.buttonok:

                Usuario usuario = new Usuario();
                usuario.setEmail(editTextemail.getText().toString());
                usuario.setNome(editTextnome.getText().toString());
                usuario.setFone_area(editTextdddarea.getText().toString());
                usuario.setFone_ddi(editTextddd.getText().toString());
                //int ddd = Integer.parseInt(editTextddd.getText().toString());
                // int ddarea = Integer.parseInt(editTextdddarea.getText().toString());
                usuario.setFonenumero(editTextfone.getText().toString());
                usuario.setTipoUsuario(spinnerusuario.getSelectedItem().toString());

                UsuarioDAO usuariodao = new UsuarioDAO(getApplicationContext());

                if(usuariodao.insert(usuario)){
                    Toast.makeText(getApplication(), "Usuario cadastrado com sucesso!!", Toast.LENGTH_LONG).show();
                    finish();
                }else{
                    Toast.makeText(getApplication(), "erro ao gravar tipo de usuario", Toast.LENGTH_LONG).show();
                }

                break;
        }

    }



    public void abrirTipoUsuario(View v){
        //startActivity(new Intent(this, TipoUsuarioActivity.class));
    }



    private void alert(String s){
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();

    }

}
