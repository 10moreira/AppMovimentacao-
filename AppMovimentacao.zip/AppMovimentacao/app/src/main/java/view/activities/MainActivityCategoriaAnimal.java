package view.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import dao.modelDao.CategoriaAnimalDAO;
import mateusmoreira.appmovimentacao.R;
import model.CategoriaAnimal;
import view.activities.MainCategoriaAnimaisListActivity;

public class MainActivityCategoriaAnimal extends AppCompatActivity implements View.OnClickListener {

    EditText editText3nomecategoria, editText6mesinicial, editText7mesfinal, editText4raca, editTextdescricao;
    Button button3Ok;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_categoria_animal);

        editText3nomecategoria = (EditText) findViewById(R.id.editText3nomecategoria);
        editText6mesinicial = (EditText) findViewById(R.id.editText6mesinicial);
        editText7mesfinal = (EditText) findViewById(R.id.editText7mesfinal);
        editText4raca = (EditText) findViewById(R.id.editText4raca);
        editTextdescricao = (EditText) findViewById(R.id.editTextdescricao);

        button3Ok = (Button) findViewById(R.id. button3Ok);

        button3Ok.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id. button3Ok:

                CategoriaAnimal categoriaanimal = new CategoriaAnimal();

                categoriaanimal.setNome(editText3nomecategoria.getText().toString());
                categoriaanimal.setRaca(editText4raca.getText().toString());
                categoriaanimal.setMeses_inicial(editText6mesinicial.getText().toString());
                categoriaanimal.setMeses_final(editText7mesfinal.getText().toString());
                categoriaanimal.setDescricao(editTextdescricao.getText().toString());

                CategoriaAnimalDAO categoriaAnimalDAO = new CategoriaAnimalDAO(getApplicationContext());

                if(categoriaAnimalDAO.insert(categoriaanimal)){
                    Toast.makeText(getApplication(), "Categoria Animal cadastrada!!", Toast.LENGTH_LONG).show();
                    finish();
                }else{
                    Toast.makeText(getApplication(), "Categoria Animal não cadastrada!!", Toast.LENGTH_LONG).show();
                }
                break;
        }

    }

    public void listacategorias(View view){
        startActivity(new Intent(this, MainCategoriaAnimaisListActivity.class));
    }

}
