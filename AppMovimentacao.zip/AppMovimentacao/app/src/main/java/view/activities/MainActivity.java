package view.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import mateusmoreira.appmovimentacao.R;
import view.activities.MainActivityCategoriaAnimal;
import view.activities.MainActivityEstoque;
import view.activities.MainActivityFazenda;
import view.activities.MainActivityMovimento;
import view.activities.MainActivityUsuario;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button buttonCadastrar;
    private Button buttonMovimentar;
    private Button buttonFazenda;
    private Button buttonCategoriAnimal;
    private Button buttonSair;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        buttonCadastrar = (Button) findViewById(R.id.buttonCadastrar);
        buttonMovimentar = (Button) findViewById(R.id.buttonMovimentar);
        buttonFazenda = (Button) findViewById(R.id.buttonFazenda);
        buttonCategoriAnimal = (Button) findViewById(R.id.buttonCategoriAnimal);
        buttonSair = (Button) findViewById(R.id.buttonSair);



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {

    }


    public void abrirCadastro(View v){
        startActivity(new Intent(this, MainActivityUsuario.class));
    }

    public void abrirMovimento(View v){
        startActivity(new Intent(this, MainActivityMovimento.class));

    }

    public void abrirFazendas(View v){
        startActivity(new Intent(this, MainActivityFazenda.class));
    }

    public void abrirCategoriaAnimais(View v){
        startActivity(new Intent(this, MainActivityCategoriaAnimal.class));
    }
    public void abrirEstoque(View v){
        startActivity(new Intent(this, MainActivityEstoque.class));
    }


    public void sair(View v){
        System.exit(0);
    }
}
