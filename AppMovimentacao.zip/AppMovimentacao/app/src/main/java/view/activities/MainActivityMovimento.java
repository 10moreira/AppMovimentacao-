package view.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import dao.modelDao.MovimentoDAO;
import mateusmoreira.appmovimentacao.R;
import model.Movimento;
import view.activities.MainActivityPotreiro;
import view.activities.MovimentacaoListActivity;

public class MainActivityMovimento extends AppCompatActivity implements View.OnClickListener {

    Spinner spinnerOrigem,spinnerdesino, spinnertipoanimal;
    EditText editTextQuantidade, editTextDatamanejo, editTextDescricao;
    Button buttonSalvar, buttonpotreiro, buttonconsultar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_movimento);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(
                this, R.array.campos, android.R.layout.simple_spinner_item);
        spinnerOrigem = (Spinner) findViewById(R.id.spinnerOrigem);
        spinnerOrigem.setAdapter(adapter1);


        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(
                this, R.array.campos, android.R.layout.simple_spinner_item);
        spinnerdesino = (Spinner) findViewById(R.id.spinnerdesino);
        spinnerdesino.setAdapter(adapter2);


        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(
                this, R.array.tipoAnimal, android.R.layout.simple_spinner_item);
        spinnertipoanimal = (Spinner) findViewById(R.id.spinnertipoanimal);
        spinnertipoanimal.setAdapter(adapter3);


        editTextDescricao = (EditText) findViewById(R.id.editTextDescricao);
        editTextQuantidade = (EditText) findViewById(R.id.editTextQuantidade);
        editTextDatamanejo = (EditText) findViewById(R.id.editTextDatamanejo);

        buttonSalvar = (Button) findViewById(R.id.buttonSalvar);
        buttonpotreiro = (Button) findViewById(R.id.buttonpotreiro);
        buttonconsultar = (Button) findViewById(R.id.buttonconsultar);


        buttonSalvar.setOnClickListener(this);

    }

    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.buttonSalvar:
                Movimento movimento = new Movimento();

                movimento.setQuantidade(editTextQuantidade.getText().toString());
                movimento.setTipo(spinnertipoanimal.getSelectedItem().toString());
                movimento.setOrigem(spinnerOrigem.getSelectedItem().toString());
                movimento.setDestino(spinnerdesino.getSelectedItem().toString());
                movimento.setDescricao(editTextDescricao.getText().toString());
                movimento.setData_movimento(editTextDatamanejo.getText().toString());

                MovimentoDAO daomovimento = new MovimentoDAO(getApplicationContext());

                if(daomovimento.insert(movimento)){
                    Toast.makeText(getApplication(), "Manejo realizado!!", Toast.LENGTH_LONG).show();
                    //startActivity(new Intent(this, TipoUsuarioActivity.class));
                    finish();
                }else{
                    Toast.makeText(getApplication(), "erro ao registrar o manejo!!", Toast.LENGTH_LONG).show();
                }
                break;
        }


    }

    public void abrirpotreiros(View v){
        startActivity(new Intent(this, MainActivityPotreiro.class));
    }

    public void abrirListMovimentos(View v){
        startActivity(new Intent(this, MovimentacaoListActivity.class));

    }

}

