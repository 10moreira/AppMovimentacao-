package view.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import dao.modelDao.FazendaDAO;
import mateusmoreira.appmovimentacao.R;
import model.Fazenda;
import view.activities.MainFazendaListActivity;

public class MainActivityFazenda extends AppCompatActivity implements View.OnClickListener {

    Spinner spinnermunicipios;
    EditText editTextnomefazenda, editText2localidade, editText4latitude, editText5longitude, editTextespacocria4;
    Button button2municipios,buttonok;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_fazenda);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //chama a Strings.xml com a lista de municipios

        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(
                this, R.array.Municipios, android.R.layout.simple_spinner_item);
        spinnermunicipios = (Spinner) findViewById(R.id.spinnermunicipios);
        spinnermunicipios.setAdapter(adapter1);



        spinnermunicipios = (Spinner) findViewById(R.id.spinnermunicipios);

        editTextnomefazenda = (EditText) findViewById(R.id.editTextnomefazenda);
        editText2localidade = (EditText) findViewById(R.id.editText2localidade);
        editText4latitude = (EditText) findViewById(R.id.editText4latitude);
        editText5longitude = (EditText) findViewById(R.id.editText5longitude);
        editTextespacocria4 = (EditText) findViewById(R.id.editTextespacocria4);

         buttonok = (Button) findViewById(R.id.buttonok);


            buttonok.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.buttonok:
                Fazenda fazenda = new Fazenda();

                fazenda.setNome(editTextnomefazenda.getText().toString());
                fazenda.setLocalidade(editText2localidade.getText().toString());
                fazenda.setLatitude(editText4latitude.getText().toString());
                fazenda.setLongitude(editText5longitude.getText().toString());
                fazenda.setEspacoparaCria(editTextespacocria4.getText().toString());
                fazenda.setMunicipioId(spinnermunicipios.getSelectedItem().toString());



                FazendaDAO fazendaDAO = new FazendaDAO(getApplicationContext());

                if(fazendaDAO.insert(fazenda)){
                    Toast.makeText(getApplication(), "Fazenda cadastrada!!", Toast.LENGTH_LONG).show();
                    finish();

                }else{
                    Toast.makeText(getApplication(), "erro ao registrar a Fazenda!!", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    public void listafazendas(View view){
        startActivity(new Intent(this, MainFazendaListActivity.class));
    }

}





