//package mateusmoreira.appmovimentacao;


/*
public class MainActivityMunicipio extends AppCompatActivity implements View.OnClickListener {

    EditText editText13nomecidade;
    Button button7ok;

*/

/*
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_municipio);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        editText13nomecidade = (EditText) findViewById(R.id.editText13nomecidade);
        button7ok = (Button) findViewById(R.id.button7ok);

        button7ok.setOnClickListener(this);

    }

*/

/*
    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.button7ok:
                Municipio municipio = new Municipio();

                municipio.setNome(editText13nomecidade.getText().toString());

                MunicipioDAO municipiodao = new MunicipioDAO(getApplicationContext());

                if(municipiodao.insert(municipio)){
                    Toast.makeText(getApplication(), "Municipio cadastradoo!!", Toast.LENGTH_LONG).show();
                    finish();
                }else {
                    Toast.makeText(getApplication(), "erro ao cadastrar o municipio!!", Toast.LENGTH_LONG).show();
                }
                 break;
        }

    }
}
*/