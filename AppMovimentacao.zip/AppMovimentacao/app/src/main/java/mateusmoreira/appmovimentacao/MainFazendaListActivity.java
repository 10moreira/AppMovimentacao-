package mateusmoreira.appmovimentacao;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import dao.helper.DatabaseOpenHelper;
import dao.modelDao.FazendaDAO;

public class MainFazendaListActivity extends Activity implements View.OnClickListener {

    private DatabaseOpenHelper helper;
    private ListView listViewFazendas;
    private ArrayAdapter<String> adpfazendas;
    private DatabaseOpenHelper database;
    private SQLiteDatabase conn;
    private FazendaDAO fazendaDAO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_fazenda_list);

        listViewFazendas = (ListView) findViewById(R.id.listViewFazendas);


        database = new DatabaseOpenHelper(this);
        conn = database.getReadableDatabase();


        fazendaDAO = new FazendaDAO(getApplicationContext());

        adpfazendas = fazendaDAO.buscafazendas(this);

        listViewFazendas.setAdapter(adpfazendas);

    }

    @Override
    public void onClick(View view) {

    }
}
