package mateusmoreira.appmovimentacao;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import model.TipoUsuario;

public class MainActivityTipoUsuario extends AppCompatActivity implements View.OnClickListener {

    EditText editTextnome;
    Button buttonok;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_tipo_usuario);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        editTextnome = (EditText) findViewById(R.id.editTextnome);
        buttonok = (Button) findViewById(R.id.buttonok);


        buttonok.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.buttonok:
                TipoUsuario tipousuario = new TipoUsuario();
                DAOTipousuario daotipousuario = new DAOTipousuario(getApplicationContext());

                tipousuario.setNome(editTextnome.getText().toString());

                if(daotipousuario.SalvarTipoUsuario(tipousuario)){

                    Toast.makeText(getApplication(), "Usuario cadastrado com sucesso!!", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(this, MainActivityUsuario.class));
                    finish();

                }else {
                    Toast.makeText(getApplication(), "Erro ao gravar usuario", Toast.LENGTH_LONG).show();
                }
                break;
        }

    }

    private void alert(String s){
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();

    }


}
