package mateusmoreira.appmovimentacao;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import model.TipoUsuario;
import model.Usuario;


public class MainActivityUsuario extends AppCompatActivity implements View.OnClickListener {

    Spinner spinner;
    EditText editTextnome, editTextemail, editTextddd, editTextdddarea, editTextfone;
    Button buttonok;
    TipoUsuario tipousuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_usuario);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        //chama a Strings.xml com a lista de municipios
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(
                this, R.array.tipousuario, android.R.layout.simple_spinner_item);
        spinner = (Spinner) findViewById(R.id.spinnerusuario);
        spinner.setAdapter(adapter1);



        editTextnome = (EditText) findViewById(R.id.editTextnome);
        //spinner = (Spinner) findViewById(R.id.spinnerusuario);
        buttonok = (Button) findViewById(R.id.buttonok);




        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                abrirusuarios(view);
            }
        });

    }

    public void abrirusuarios(View view) {
        startActivity(new Intent(this, MainActivityTipoUsuario.class));
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.buttonok:
                Usuario usuario = new Usuario();
                TipoUsuario tipousuario = new TipoUsuario();
                DAOusuario daousuario = new DAOusuario(getApplicationContext());


                usuario.setNome(editTextnome.getText().toString());
                usuario.setEmail(editTextemail.getText().toString());
                usuario.setFone_area(editTextdddarea.getInputType());
                usuario.setFone_ddi(editTextddd.getInputType());
                usuario.setFonenumero(editTextfone.getText().toString());
                tipousuario.setNome(editTextnome.getText().toString());

                if(daousuario.SalvarUsuario(usuario)){
                    Toast.makeText(getApplication(), "Usuario cadastrado com sucesso!!", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(this, MainActivityUsuario.class));
                    finish();

                }else {
                    Toast.makeText(getApplication(), "Erro ao gravar usuario", Toast.LENGTH_LONG).show();
                }
                break;
        }

    }

    private void alert(String s){
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();

    }

}
