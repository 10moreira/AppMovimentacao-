package mateusmoreira.appmovimentacao;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import dao.helper.DatabaseOpenHelper;
import dao.modelDao.EstoqueDAO;

public class MainEstoqueListActivity extends Activity implements View.OnClickListener {

    private DatabaseOpenHelper helper;
    private ListView listViewestoque;
    private ArrayAdapter<String> adpestoque;
    private DatabaseOpenHelper database;
    private SQLiteDatabase conn;
    private EstoqueDAO estoqueDAO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_estoque_list);

        listViewestoque = (ListView) findViewById(R.id.listViewestoque);


        database = new DatabaseOpenHelper(this);
        conn = database.getReadableDatabase();


        estoqueDAO = new EstoqueDAO(getApplicationContext());

        adpestoque = estoqueDAO.buscaestoque(this);

        listViewestoque.setAdapter(adpestoque);



    }

    @Override
    public void onClick(View view) {

    }
}
