package mateusmoreira.appmovimentacao;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import dao.modelDao.PotreiroDAO;
import model.Potreiro;

public class MainActivityPotreiro extends AppCompatActivity implements View.OnClickListener {

    EditText editText4nomepotreiro, editText5tamanhoPotreiro;
    Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_potreiro);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


                editText4nomepotreiro = (EditText) findViewById(R.id.editText4nomepotreiro);
                editText5tamanhoPotreiro = (EditText) findViewById(R.id.editText5tamanhoPotreiro);

                button2 = (Button) findViewById(R.id.button2);

                button2.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id. button2:

                Potreiro potreiro = new Potreiro();

                potreiro.setNomePotreiro(editText4nomepotreiro.getText().toString());
                potreiro.setTamanhopotreiro(editText5tamanhoPotreiro.getText().toString());


                PotreiroDAO potreirodao = new PotreiroDAO(getApplicationContext());

                if(potreirodao.insert(potreiro)){
                    Toast.makeText(getApplication(), "Potreiro cadastrado!!", Toast.LENGTH_LONG).show();
                    finish();
                }else{
                    Toast.makeText(getApplication(), "Potreiro cadastrado!!", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }
}
