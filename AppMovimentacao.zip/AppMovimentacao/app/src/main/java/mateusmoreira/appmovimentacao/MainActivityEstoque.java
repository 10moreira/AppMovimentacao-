package mateusmoreira.appmovimentacao;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import dao.modelDao.EstoqueDAO;
import model.Estoque;

public class MainActivityEstoque  extends AppCompatActivity implements View.OnClickListener {

    EditText editTextSaldo, editText2NrodeAnimais, editText3areaCriacao;
    Spinner spinnerOrigem, spinnerDestino, spinner3Generoanimal, spinnerPropriedade;
    Button button4ok;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity_estoque);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        editText2NrodeAnimais = (EditText) findViewById(R.id.editText2NrodeAnimais);
        editTextSaldo = (EditText) findViewById(R.id.editTextSaldo);
        editText3areaCriacao = (EditText) findViewById(R.id.editText3areaCriacao);

        spinnerOrigem = (Spinner) findViewById(R.id.spinnerOrigem);
        spinnerDestino = (Spinner) findViewById(R.id.spinnerDestino);
        spinner3Generoanimal = (Spinner) findViewById(R.id.spinner3Generoanimal);
     //   spinnerPropriedade = (Spinner) findViewById(R.id.spinnerPropriedade);

        button4ok = (Button) findViewById(R.id.button4ok);




    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.button4ok:

                Estoque estoque = new Estoque();

                estoque.setSaldo(editTextSaldo.getText().toString());
                estoque.setNumeroAnimais(editText2NrodeAnimais.getText().toString());
                estoque.setAreaCriacao(editText3areaCriacao.getText().toString());
                estoque.setOrigem(spinnerOrigem.getSelectedItem().toString());
                estoque.setDestino(spinnerDestino.getSelectedItem().toString());
                estoque.setGenero_animal(spinner3Generoanimal.getSelectedItem().toString());
                //estoque.setFazenda(spinnerPropriedade.getSelectedItem().toString());

                EstoqueDAO estoqueDAO = new EstoqueDAO(getApplicationContext());


                if(estoqueDAO.insert(estoque)){
                    Toast.makeText(getApplication(), "Estoque registrado!!", Toast.LENGTH_LONG).show();
                    finish();

                }else{
                    Toast.makeText(getApplication(), "erro ao registrar estoque!!", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    public void listaestoques(View view){
        startActivity(new Intent(this, MainEstoqueListActivity.class));
    }

}
