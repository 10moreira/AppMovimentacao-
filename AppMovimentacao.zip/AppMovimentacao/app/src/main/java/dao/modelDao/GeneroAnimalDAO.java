/*
package dao.modelDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.helper.DatabaseOpenHelper;
import model.GeneroAnimal;

/**
 * Created by mateus on 30/10/17.
 */
/*
public class GeneroAnimalDAO {

    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_GENEROANIMAL[] = {
            DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_ID,
            DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_SEXO,
            DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_DESCRICAO,
            DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_CATEGORIA_ANIMAL,
    };

    private Context mContext;

    public GeneroAnimalDAO(Context context){
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close(){
        helper.close();
    }

    public void salva(GeneroAnimal generoAnimal) {
        /**
         * Se o ID do item é nulo é porque ele ainda não existe no banco de
         * dados, logo subentende-se que queremos adicionar o item no banco de
         * dados. Sendo assim, chamaremos o método adiciona() já definido no
         * DAO.
         */

/*
        GeneroAnimal generoAnimales = getGeneroAnimal(generoAnimal.getId());

        if ( generoAnimal == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(generoAnimal);
            /**
             * Caso o item possua um ID é porque ele já existe no banco de
             * dados, logo subentende-se que queremos alterar seus dados no
             * banco de dados. Sendo assim, chamaremos o método atualiza() já
             * definido no DAO.
             */

/*
        } else {
            update(generoAnimal, generoAnimal.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }
    }
    public boolean insert(GeneroAnimal generoAnimal){
        ContentValues values = new ContentValues();
        SQLiteDatabase db = helper.getWritableDatabase();
        //Item

        values.put("_id", generoAnimal.getId());
        values.put("sexo", generoAnimal.getSexo());
        values.put("decricao", generoAnimal.getDescricao());



        long cadastrageneroAnimal = db.insert(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL, null, values);


        return true;

      //  values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_SEXO, generoAnimal.getSexo());
        //values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_DESCRICAO, generoAnimal.getDescricao());
       // values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_CATEGORIA_ANIMAL, generoAnimal.getCategoria_animal());

        /*
        if(database.insert(DatabaseOpenHelper.TABLE_GENEROANIMAL, null, values) == -1){
            return false;
        }

        */

/*
    }

    public int insertCopy(GeneroAnimal generoAnimal){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_ID, generoAnimal.getId());
        values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_SEXO, generoAnimal.getSexo());
        values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_DESCRICAO, generoAnimal.getDescricao());
        //values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_CATEGORIA_ANIMAL, generoAnimal.getCategoria_animal());

        int idInsert = (int) database.insert(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL, null, values);
        if( idInsert != -1){
            return idInsert;
        }
        return -1;
    }

    public boolean update(GeneroAnimal generoAnimal, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_ID, generoAnimal.getId());
        values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_SEXO, generoAnimal.getSexo());
        values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_DESCRICAO, generoAnimal.getDescricao());

        if(database.update(DatabaseOpenHelper.TABLE_GENEROANIMAL, values, DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }



    public boolean updateIsFavorite(GeneroAnimal generoAnimal) {
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_GENEROANIMAL, generoAnimal.getId());

        if(database.update(DatabaseOpenHelper.TABLE_GENEROANIMAL, values, DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_ID + " = '" + generoAnimal.getId() + "'", null) == -1){
            return false;
        }

        return true;
    }


    public void delete(int codigo){
        database.delete(DatabaseOpenHelper.TABLE_ESTOQUE, DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ID + " = '" + codigo + "'", null);
    }
    /**
     * Retorna todos os itens cadastrados.
     */

/*
    public List<GeneroAnimal> getAllGeneroAnimal(){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_GENEROANIMAL, TABLE_GENEROANIMAL, null, null, null, null, DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_SALDO + " ASC; ");
        cursor.moveToFirst();

        List<GeneroAnimal> generoAnimal = new ArrayList<GeneroAnimal>();
        while(!cursor.isAfterLast()){
            generoAnimal.add(cursorForItem(cursor));
            cursor.moveToNext();
        }
        cursor.close();
        return generoAnimal;
    }

    public GeneroAnimal getGeneroAnimal(int codigo){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_ESTOQUE, TABLE_GENEROANIMAL, DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_ID + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        GeneroAnimal generoAnimal = null;
        if(!cursor.isAfterLast()){
            generoAnimal = cursorForItem(cursor);
        }

        cursor.close();
        return generoAnimal;
    }

    public GeneroAnimal cursorForItem(Cursor cursor){
        GeneroAnimal generoAnimal = new GeneroAnimal();

        generoAnimal.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_ID)));
        generoAnimal.setSexo(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_SEXO)));
        generoAnimal.setDescricao(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_GENEROANIMAL_COLUMN_DESCRICAO)));

        return generoAnimal;
    }

}
*/