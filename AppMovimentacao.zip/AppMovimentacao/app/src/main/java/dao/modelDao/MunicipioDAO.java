package dao.modelDao;

/**
 * Created by mateus on 30/10/17.
 */
/*
public class MunicipioDAO {

    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_MUNICIPIO[] = {
            DatabaseOpenHelper.TABLE_MUNICIPIO_COLUMN_ID,
            DatabaseOpenHelper.TABLE_MUNICIPIO_COLUMN_NOME,
    };

    private Context mContext;


    public MunicipioDAO(Context context){
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close(){
        helper.close();
    }
*/
/*
    public void salva(Municipio municipio) {
        /**
         * Se o ID do item é nulo é porque ele ainda não existe no banco de
         * dados, logo subentende-se que queremos adicionar o item no banco de
         * dados. Sendo assim, chamaremos o método adiciona() já definido no
         * DAO.
         */
/*
        Municipio municipios = getMunicipio(municipio.getId());

        if ( municipio == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(municipio);
            /**
             * Caso o item possua um ID é porque ele já existe no banco de
             * dados, logo subentende-se que queremos alterar seus dados no
             * banco de dados. Sendo assim, chamaremos o método atualiza() já
             * definido no DAO.
             */

/*
        } else {
            update(municipio, municipio.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }
    }
    public boolean insert(Municipio municipio){

        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        //Item

        values.put("nome", municipio.getNome());

        long inserimunicipio = db.insert(DatabaseOpenHelper.TABLE_MUNICIPIO, null, values);
        /*
        if(database.insert(DatabaseOpenHelper.TABLE_MUNICIPIO, null, values) == -1){
            return false;
        }
*/
       /*
        return true;
    }

    public int insertCopy(Municipio municipio){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_MUNICIPIO_COLUMN_NOME, municipio.getNome());

        int idInsert = (int) database.insert(DatabaseOpenHelper.TABLE_MUNICIPIO, null, values);
        if( idInsert != -1){
            return idInsert;
        }
        return -1;
    }

    public boolean update(Municipio municipio, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_MUNICIPIO_COLUMN_NOME, municipio.getNome());

        if(database.update(DatabaseOpenHelper.TABLE_MUNICIPIO, values, DatabaseOpenHelper.TABLE_MUNICIPIO_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }



    public boolean updateIsFavorite(Municipio municipio) {
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_MUNICIPIO_COLUMN_NOME, municipio.getNome());

        if(database.update(DatabaseOpenHelper.TABLE_MUNICIPIO, values, DatabaseOpenHelper.TABLE_MUNICIPIO_COLUMN_ID + " = '" + municipio.getId() + "'", null) == -1){
            return false;
        }

        return true;
    }
*/
/*
    public void delete(int codigo){
        database.delete(DatabaseOpenHelper.TABLE_ESTOQUE, DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ID + " = '" + codigo + "'", null);
    }
    /*
    /**
     * Retorna todos os itens cadastrados.
     */


/*
    public List<Municipio> getAllMunicipio(){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_MUNICIPIO, TABLE_MUNICIPIO, null, null, null, null, DatabaseOpenHelper.TABLE_MUNICIPIO_COLUMN_NOME + " ASC; ");
        cursor.moveToFirst();

        List<Municipio> municipio = new ArrayList<Municipio>();
        while(!cursor.isAfterLast()){
            municipio.add(cursorForItem(cursor));
            cursor.moveToNext();
        }
        cursor.close();
        return municipio;
    }
    */

/*
    public Municipio getMunicipio(int codigo){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_MUNICIPIO, TABLE_MUNICIPIO, DatabaseOpenHelper.TABLE_MUNICIPIO + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        Municipio municipio = null;
        if(!cursor.isAfterLast()){
            municipio = cursorForItem(cursor);
        }

        cursor.close();
        return municipio;
    }

    public Municipio cursorForItem(Cursor cursor){
        Municipio municipio = new Municipio();

        municipio.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_MUNICIPIO_COLUMN_ID)));
        municipio.setNome(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_MUNICIPIO_COLUMN_NOME)));

        return municipio;
    }
}
*/

