package dao.modelDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.helper.DatabaseOpenHelper;
import model.Usuario;

/**
 * Created by mateus on 30/10/17.
 */
public class UsuarioDAO {

    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_USUARIO_COLUMNS[] = {
            DatabaseOpenHelper.TABLE_USUARIO_COLUMN_ID,
            DatabaseOpenHelper.TABLE_USUARIO_COLUMN_NOME,
            DatabaseOpenHelper.TABLE_USUARIO_COLUN_EMAIL,
            DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE,
            DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE_DDI,
            DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE_AREA,

    };

    private Context mContext;


    public UsuarioDAO(Context context){
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close(){
        helper.close();
    }

    public void salva(Usuario usuario) {
        /**
         * Se o ID do item é nulo é porque ele ainda não existe no banco de
         * dados, logo subentende-se que queremos adicionar o item no banco de
         * dados. Sendo assim, chamaremos o método adiciona() já definido no
         * DAO.
         */

        Usuario usuarios = getUsuario(usuario.getId());

        if ( usuario == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(usuario);
            /**
             * Caso o item possua um ID é porque ele já existe no banco de
             * dados, logo subentende-se que queremos alterar seus dados no
             * banco de dados. Sendo assim, chamaremos o método atualiza() já
             * definido no DAO.
             */
        } else {
            update(usuario, usuario.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }
    }

    public boolean insert(Usuario usuario){

        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        //Item
        values.put("id", usuario.getId());
        values.put("email", usuario.getEmail());
        values.put("nome", usuario.getNome());
        values.put("fone", usuario.getFonenumero());
        values.put("fonearea", usuario.getFone_area());
        values.put("ddi", usuario.getFone_ddi());
        values.put("tipo", usuario.getTipoUsuario());

        long usuarioinserir = db.insert(DatabaseOpenHelper.TABLE_USUARIO, null, values);


        // if(database.insert(DatabaseOpenHelper.TABLE_USUARIO, null, values) == -1){
         //   return false;
        //}
        return true;
    }

    public int insertCopy(Usuario usuario){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_NOME, usuario.getNome());
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUN_EMAIL, usuario.getEmail());
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE, usuario.getFonenumero());
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE_AREA, usuario.getFone_area());
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE_DDI, usuario.getFone_ddi());


        int idInsert = (int) database.insert(DatabaseOpenHelper.TABLE_USUARIO, null, values);
        if( idInsert != -1){
            return idInsert;
        }
        return -1;
    }

    public boolean update(Usuario usuario, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_NOME, usuario.getNome());
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUN_EMAIL, usuario.getEmail());
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE, usuario.getFonenumero());
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE_AREA, usuario.getFone_area());
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE_DDI, usuario.getFone_ddi());


        if(database.update(DatabaseOpenHelper.TABLE_USUARIO, values, DatabaseOpenHelper.TABLE_USUARIO_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }



    public boolean updateIsFavorite(Usuario usuario) {
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_NOME, usuario.getNome());

        if(database.update(DatabaseOpenHelper.TABLE_USUARIO, values, DatabaseOpenHelper.TABLE_USUARIO_COLUMN_ID + " = '" + usuario.getId() + "'", null) == -1){
            return false;
        }

        return true;
    }


    public void delete(int codigo){
        database.delete(DatabaseOpenHelper.TABLE_USUARIO, DatabaseOpenHelper.TABLE_USUARIO_COLUMN_ID + " = '" + codigo + "'", null);
    }
    /**
     * Retorna todos os itens cadastrados.
     */
    public List<Usuario> getAllUsuario(){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_USUARIO, TABLE_USUARIO_COLUMNS, null, null, null, null, DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE + " ASC; ");
        cursor.moveToFirst();

        List<Usuario> usuario = new ArrayList<Usuario>();
        while(!cursor.isAfterLast()){
            usuario.add(cursorForItem(cursor));
            cursor.moveToNext();
        }
        cursor.close();
        return usuario;
    }

    public Usuario getUsuario(int codigo){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_USUARIO, TABLE_USUARIO_COLUMNS, DatabaseOpenHelper.TABLE_USUARIO_COLUMN_ID + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        Usuario usuario = null;
        if(!cursor.isAfterLast()){
            usuario = cursorForItem(cursor);
        }

        cursor.close();
        return usuario;
    }

    public Usuario cursorForItem(Cursor cursor){
        Usuario usuario = new Usuario();

        usuario.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_ID)));
        usuario.setNome(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_NOME)));
        usuario.setEmail(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_USUARIO_COLUN_EMAIL)));
        usuario.setFonenumero(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE)));
        //usuario.setFone_area(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE_AREA)));
        //usuario.setFone_ddi(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_USUARIO_COLUMN_FONE_DDI)));

        return usuario;
    }


}
