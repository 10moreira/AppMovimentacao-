/*

package dao.modelDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.helper.DatabaseOpenHelper;
import model.OrigemDestino;

/**
 * Created by mateus on 30/10/17.
 */
/*
public class OrigemDestinoDAO {

    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_ORIGEMDESTINO_COLUMNS[] = {
            DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_ID,
            DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_DECRICAO,
            DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_TIPO,
    };
*/

  /*
    private Context mContext;


    public OrigemDestinoDAO(Context context){
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close(){
        helper.close();
    }
*/

/*
    public void salva(OrigemDestino origemdestino) {

        OrigemDestino origemdestinos = getOrigemDestino(origemdestino.getId());

        if ( origemdestino == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(origemdestino);

        } else {
            update(origemdestino, origemdestino.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }

    }
*/


/*

    public boolean insert(OrigemDestino origemDestino){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_ID, origemDestino.getId());
      //  values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO, origemDestino.getOrigem_destino());
        values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_DECRICAO, origemDestino.getDescricao());
        values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_TIPO, origemDestino.getTipo());

        if(database.insert(DatabaseOpenHelper.TABLE_ORIGEMDESTINO, null, values) == -1){
            return false;
        }
        return true;
    }

*/


/*
    public int insertCopy(OrigemDestino origemDestino){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_ID, origemDestino.getId());
//        values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO, origemDestino.getOrigem_destino());
        values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_DECRICAO, origemDestino.getDescricao());
        values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_TIPO, origemDestino.getTipo());

        int idInsert = (int) database.insert(DatabaseOpenHelper.TABLE_ORIGEMDESTINO, null, values);
        if( idInsert != -1){
            return idInsert;
        }
        return -1;
    }

*/



/*
    public boolean update(OrigemDestino origemDestino, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_ID, origemDestino.getId());
  //      values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO, origemDestino.getOrigem_destino());
        values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_DECRICAO, origemDestino.getDescricao());
        values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_TIPO, origemDestino.getTipo());

        if(database.update(DatabaseOpenHelper.TABLE_ORIGEMDESTINO, values, DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }



    public boolean updateIsFavorite(OrigemDestino origemDestino) {
        ContentValues values = new ContentValues();
        //Item
    //    values.put(DatabaseOpenHelper.TABLE_ORIGEMDESTINO, origemDestino.getOrigem_destino());

        if(database.update(DatabaseOpenHelper.TABLE_ORIGEMDESTINO, values, DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_ID + " = '" + origemDestino.getId() + "'", null) == -1){
            return false;
        }

        return true;
    }

*/


/*
    public void delete(int codigo){
        database.delete(DatabaseOpenHelper.TABLE_ORIGEMDESTINO, DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_ID + " = '" + codigo + "'", null);
    }

    public List<OrigemDestino> getAllOrigemDestino(){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_ORIGEMDESTINO, TABLE_ORIGEMDESTINO_COLUMNS, null, null, null, null, DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_SALDO + " ASC; ");
        cursor.moveToFirst();

        List<OrigemDestino> origemDestino = new ArrayList<OrigemDestino>();
        while(!cursor.isAfterLast()){
            origemDestino.add(cursorForItem(cursor));
            cursor.moveToNext();
        }
        cursor.close();
        return origemDestino;
    }

    public OrigemDestino getOrigemDestino(int codigo){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_ESTOQUE, TABLE_ORIGEMDESTINO_COLUMNS, DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_ID + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        OrigemDestino origemDestino = null;
        if(!cursor.isAfterLast()){
            origemDestino = cursorForItem(cursor);
        }

        cursor.close();
        return origemDestino;
    }

    public OrigemDestino cursorForItem(Cursor cursor){
        OrigemDestino origemDestino = new OrigemDestino();

        origemDestino.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_ID)));
      //  origemDestino.setOrigem_destino(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_DECRICAO)));
        origemDestino.setTipo(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_ORIGEMDESTINO_COLUMN_TIPO)));

        return origemDestino;
    }


}

*/