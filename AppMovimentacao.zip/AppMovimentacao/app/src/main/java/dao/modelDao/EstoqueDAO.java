package dao.modelDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.ArrayAdapter;

import dao.helper.DatabaseOpenHelper;
import model.Estoque;

/**
 * Created by mateus on 06/10/17.
 */
public class EstoqueDAO {

    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_ESTOQUE_COLUMNS[] = {
            DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ID,
            DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_SALDO,
            DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ORIGEM,
            DatabaseOpenHelper.TABLE_ESTOQUE_COLMUN_DESTINO,
            DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_AREACRIACAO,
            DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_GENEROANIMAL,
            DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_TOTALANIMAIS,
            DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_FAZENDA,
    };

    private Context mContext;


    public EstoqueDAO(Context context){
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close(){
        helper.close();
    }

    public void salva(Estoque estoque) {
        /**
         * Se o ID do item é nulo é porque ele ainda não existe no banco de
         * dados, logo subentende-se que queremos adicionar o item no banco de
         * dados. Sendo assim, chamaremos o método adiciona() já definido no
         * DAO.
         */

        Estoque estoquem = getEstoque(estoque.getId());

        if ( estoque == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(estoque);
            /**
             * Caso o item possua um ID é porque ele já existe no banco de
             * dados, logo subentende-se que queremos alterar seus dados no
             * banco de dados. Sendo assim, chamaremos o método atualiza() já
             * definido no DAO.
             */
        } else {
            update(estoque, estoque.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }
    }
    public boolean insert(Estoque estoque){

        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("_id", estoque.getId());
        values.put("saldo", estoque.getSaldo());
        values.put("nrototalanimais", estoque.getNumeroAnimais());
        values.put("origem", estoque.getOrigem());
        values.put("destino", estoque.getDestino());
        values.put("areaCriacao", estoque.getAreaCriacao());
        values.put("generoAnimal", estoque.getGenero_animal());


        long registraestoque = db.insert(DatabaseOpenHelper.TABLE_ESTOQUE, null, values);

        return true;


        /*
        if(database.insert(DatabaseOpenHelper.TABLE_ESTOQUE, null, values) == -1){
            return false;
        }
        return true;
        */
    }

    public int insertCopy(Estoque estoque){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_SALDO, estoque.getSaldo());
      //  values.put(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ORIGEMDESTINO, estoque.getOrigem_destino());
        //values.put(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_GENEROANIMAL, estoque.getGenero_animal());
        //values.put(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_FAZENDA, estoque.getFazenda());

        int idInsert = (int) database.insert(DatabaseOpenHelper.TABLE_ESTOQUE, null, values);
        if( idInsert != -1){
            return idInsert;
        }
        return -1;
    }

    public boolean update(Estoque estoque, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ID, estoque.getId());
        values.put(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_SALDO, estoque.getSaldo());
    //    values.put(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ORIGEMDESTINO, estoque.getOrigem_destino());
      //  values.put(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_GENEROANIMAL, estoque.getGenero_animal());
       // values.put(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_FAZENDA, estoque.getFazenda());

        if(database.update(DatabaseOpenHelper.TABLE_ESTOQUE, values, DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }



    public boolean updateIsFavorite(Estoque estoque) {
        ContentValues values = new ContentValues();
        //Item
     //   values.put(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ORIGEMDESTINO, estoque.getOrigem_destino());

        if(database.update(DatabaseOpenHelper.TABLE_ESTOQUE, values, DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ID + " = '" + estoque.getId() + "'", null) == -1){
            return false;
        }

        return true;
    }


    public void delete(int codigo){
        database.delete(DatabaseOpenHelper.TABLE_ESTOQUE, DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ID + " = '" + codigo + "'", null);
    }
    /**
     * Retorna todos os itens cadastrados.
     */

    public ArrayAdapter<String> buscaestoque(Context context){

        ArrayAdapter<String>adpestoque = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1);

        SQLiteDatabase db = helper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM tb_estoque", null);

        if(cursor.getCount() > 0){
            cursor.moveToFirst();

            do {

                String saldo = cursor.getString(1);
                String nrototalanimais = cursor.getString(2);
                String destino = cursor.getString(3);
                String areacriacao = cursor.getString(4);
                String generoAnimal = cursor.getString(6);

                adpestoque.add(saldo);
                adpestoque.add(nrototalanimais);
                adpestoque.add(destino);
                adpestoque.add(areacriacao);
                adpestoque.add(generoAnimal);


            }while (cursor.moveToNext());
        }

        return adpestoque;

    }




    public Estoque getEstoque(int codigo){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_ESTOQUE, TABLE_ESTOQUE_COLUMNS, DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ID + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        Estoque estoque = null;
        if(!cursor.isAfterLast()){
            estoque = cursorForItem(cursor);
        }

        cursor.close();
        return estoque;
    }

    public Estoque cursorForItem(Cursor cursor){
        Estoque estoque = new Estoque();

        estoque.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ID)));
        estoque.setAreaCriacao(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_AREACRIACAO)));
        estoque.setGenero_animal(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_GENEROANIMAL)));
        estoque.setOrigem(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_ORIGEM)));
        estoque.setDestino(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_ESTOQUE_COLMUN_DESTINO)));
        estoque.setSaldo(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_SALDO)));
        estoque.setNumeroAnimais(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_TOTALANIMAIS)));

        return estoque;
    }

}
