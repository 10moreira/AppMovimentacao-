package dao.modelDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.ArrayAdapter;

import dao.helper.DatabaseOpenHelper;
import model.CategoriaAnimal;

/**
 * Created by mateus on 24/10/17.
 */
public class CategoriaAnimalDAO {


    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_CATEGORIAANIMAL[] = {
            DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_ID,
            DatabaseOpenHelper.TABLE_CATGORIAANIMAL_COLUMN_NOME,
            DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_RACA,
            DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_MESESINICIAIS,
            DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_MESESFINAIS,
    };

    private Context mContext;


    public CategoriaAnimalDAO(Context context){
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close(){
        helper.close();
    }

    public void salva(CategoriaAnimal categoriaAnimal) {
        /**
         * Se o ID do item é nulo é porque ele ainda não existe no banco de
         * dados, logo subentende-se que queremos adicionar o item no banco de
         * dados. Sendo assim, chamaremos o método adiciona() já definido no
         * DAO.
         */

        CategoriaAnimal categoriasanimais = getCategoriaAnimal(categoriaAnimal.getId());

        if ( categoriaAnimal == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(categoriaAnimal);
            /**
             * Caso o item possua um ID é porque ele já existe no banco de
             * dados, logo subentende-se que queremos alterar seus dados no
             * banco de dados. Sendo assim, chamaremos o método atualiza() já
             * definido no DAO.
             */
        } else {
            update(categoriaAnimal, categoriaAnimal.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }
    }
    public boolean insert(CategoriaAnimal categoriaAnimal){

        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        //Item
        values.put("_id", categoriaAnimal.getId());
        values.put("nome", categoriaAnimal.getNome());
        values.put("raca", categoriaAnimal.getRaca());
        values.put("mesesiniciais", categoriaAnimal.getMeses_inicial());
        values.put("mesesfinais", categoriaAnimal.getMeses_final());
        values.put("descricao", categoriaAnimal.getDescricao());

        long registracategoria = db.insert(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL, null, values);

/*
        if(database.insert(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL, null, values) == -1){
            return false;
        }
        */
        return true;
    }

    public int insertCopy(CategoriaAnimal categoriaAnimal){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper. TABLE_CATGORIAANIMAL_COLUMN_NOME, categoriaAnimal.getNome());
        values.put(DatabaseOpenHelper. TABLE_CATEGORIAANIMAL_COLUMN_MESESINICIAIS, categoriaAnimal.getMeses_inicial());
        values.put(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_MESESFINAIS, categoriaAnimal.getMeses_final());

        int idInsert = (int) database.insert(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL, null, values);
        if( idInsert != -1){
            return idInsert;
        }
        return -1;
    }

    public boolean update(CategoriaAnimal categoriaAnimal, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_ID, categoriaAnimal.getId());
        values.put(DatabaseOpenHelper. TABLE_CATGORIAANIMAL_COLUMN_NOME, categoriaAnimal.getNome());
        values.put(DatabaseOpenHelper. TABLE_CATEGORIAANIMAL_COLUMN_MESESINICIAIS, categoriaAnimal.getMeses_inicial());
        values.put(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_MESESFINAIS, categoriaAnimal.getMeses_final());

        if(database.update(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL, values, DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }

    public boolean updateIsFavorite(CategoriaAnimal categoriaAnimal) {
        ContentValues values = new ContentValues();

        //Item
        values.put(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_ID, categoriaAnimal.getId());

        if(database.update(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL, values, DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_ID + " = '" + categoriaAnimal.getId() + "'", null) == -1){
            return false;
        }

        return true;
    }


    public void delete(int codigo){
        database.delete(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL, DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_ID + " = '" + codigo + "'", null);
    }
    /**
     * Retorna todos os itens cadastrados.
     */


    public ArrayAdapter<String> buscacategorias(Context context){

        ArrayAdapter<String>adpcategorias = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1);

        SQLiteDatabase db = helper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM tb_categoriaAnimal", null);

        if(cursor.getCount() > 0){
            cursor.moveToFirst();

            do {


                String nome = cursor.getString(1);
                String raca = cursor.getString(2);
                String descricao = cursor.getString(3);

                adpcategorias.add(nome);
                adpcategorias.add(raca);
                adpcategorias.add(descricao);


            }while (cursor.moveToNext());
        }

        return adpcategorias;

    }




    public CategoriaAnimal getCategoriaAnimal(int codigo){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL, TABLE_CATEGORIAANIMAL, DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_ID + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        CategoriaAnimal categoriaAnimal = null;
        if(!cursor.isAfterLast()){
            categoriaAnimal = cursorForItem(cursor);
        }

        cursor.close();
        return categoriaAnimal;
    }

    public CategoriaAnimal cursorForItem(Cursor cursor){
        CategoriaAnimal categoriaAnimal = new CategoriaAnimal();

        categoriaAnimal.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_ID)));
        categoriaAnimal.setNome(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_CATGORIAANIMAL_COLUMN_NOME)));
        categoriaAnimal.setRaca(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_RACA)));
        categoriaAnimal.setMeses_inicial(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_MESESINICIAIS)));
        categoriaAnimal.setMeses_final(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_CATEGORIAANIMAL_COLUMN_MESESFINAIS)));

        return categoriaAnimal;
    }

}
