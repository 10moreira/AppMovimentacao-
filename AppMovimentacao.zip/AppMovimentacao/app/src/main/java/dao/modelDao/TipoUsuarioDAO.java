package dao.modelDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.helper.DatabaseOpenHelper;
import model.TipoUsuario;

/**
 * Created by mateus on 30/10/17.
 */
public class TipoUsuarioDAO {

    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_TIPOUSUARIO_COLUMNS[] = {
            DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_ID,
            DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_NOME,
    };

    private Context mContext;


    public TipoUsuarioDAO(Context context){
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close(){
        helper.close();
    }

    public void salva(TipoUsuario tipousuario) {
        /**
         * Se o ID do item é nulo é porque ele ainda não existe no banco de
         * dados, logo subentende-se que queremos adicionar o item no banco de
         * dados. Sendo assim, chamaremos o método adiciona() já definido no
         * DAO.
         */

        TipoUsuario tipousuarios = getTipoUsuario(tipousuario.getId());

        if ( tipousuario == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(tipousuario);
            /**
             * Caso o item possua um ID é porque ele já existe no banco de
             * dados, logo subentende-se que queremos alterar seus dados no
             * banco de dados. Sendo assim, chamaremos o método atualiza() já
             * definido no DAO.
             */
        } else {
            update(tipousuario, tipousuario.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }
    }
    public boolean insert(TipoUsuario tipousuario){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_NOME, tipousuario.getNome());

        if(database.insert(DatabaseOpenHelper.TABLE_TIPOUSUARIO, null, values) == -1){
            return false;
        }
        return true;
    }

    public int insertCopy(TipoUsuario tipousuario){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_NOME, tipousuario.getNome());

        int idInsert = (int) database.insert(DatabaseOpenHelper.TABLE_TIPOUSUARIO, null, values);
        if( idInsert != -1){
            return idInsert;
        }
        return -1;
    }

    public boolean update(TipoUsuario tipousuario, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_NOME, tipousuario.getNome());

        if(database.update(DatabaseOpenHelper.TABLE_TIPOUSUARIO, values, DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }



    public boolean updateIsFavorite(TipoUsuario tipousuario) {
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_NOME, tipousuario.getNome());

        if(database.update(DatabaseOpenHelper.TABLE_TIPOUSUARIO, values, DatabaseOpenHelper.TABLE_TIPOUSUARIO + " = '" + tipousuario.getId() + "'", null) == -1){
            return false;
        }

        return true;
    }


    public void delete(int codigo){
        database.delete(DatabaseOpenHelper.TABLE_TIPOUSUARIO, DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_ID + " = '" + codigo + "'", null);
    }
    /**
     * Retorna todos os itens cadastrados.
     */
    public List<TipoUsuario> getAllTipoUsuario(){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_TIPOUSUARIO, TABLE_TIPOUSUARIO_COLUMNS, null, null, null, null, DatabaseOpenHelper.TABLE_ESTOQUE_COLUMN_SALDO + " ASC; ");
        cursor.moveToFirst();

        List<TipoUsuario> tipousuario = new ArrayList<TipoUsuario>();
        while(!cursor.isAfterLast()){
            tipousuario.add(cursorForItem(cursor));
            cursor.moveToNext();
        }
        cursor.close();
        return tipousuario;
    }

    public TipoUsuario getTipoUsuario(int codigo){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_TIPOUSUARIO, TABLE_TIPOUSUARIO_COLUMNS, DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_ID + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        TipoUsuario tipousuario = null;
        if(!cursor.isAfterLast()){
            tipousuario = cursorForItem(cursor);
        }

        cursor.close();
        return tipousuario;
    }

    public TipoUsuario cursorForItem(Cursor cursor){
        TipoUsuario tipousuario = new TipoUsuario();


        tipousuario.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_ID)));
        tipousuario.setNome(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_TIPOUSUARIO_COLUMN_NOME)));


        return tipousuario;
    }




}
