package dao.modelDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.ArrayAdapter;

import java.sql.SQLException;

import dao.helper.DatabaseOpenHelper;
import model.Fazenda;

/**
 * Created by mateus on 30/10/17.
 */
public class FazendaDAO {

    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_FAZENDA[] = {
            DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_ID,
            DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_NOME,
            DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LOCALIDADE,
            DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LATITUDE,
            DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LONGITUDE,
            DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_MUNICIPIO
    };

    private Context mContext;


    public FazendaDAO(Context context){
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close(){
        helper.close();
    }

    public void salva(Fazenda fazenda) {
        /**
         * Se o ID do item é nulo é porque ele ainda não existe no banco de
         * dados, logo subentende-se que queremos adicionar o item no banco de
         * dados. Sendo assim, chamaremos o método adiciona() já definido no
         * DAO.
         */

        Fazenda fazendam = getFazenda(fazenda.getId());

        if ( fazenda == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(fazenda);
            /**
             * Caso o item possua um ID é porque ele já existe no banco de
             * dados, logo subentende-se que queremos alterar seus dados no
             * banco de dados. Sendo assim, chamaremos o método atualiza() já
             * definido no DAO.
             */
        } else {
            update(fazenda, fazenda.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }
    }
    public boolean insert(Fazenda fazenda){

        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        //Item

        values.put("_id", fazenda.getId());
        values.put("nome", fazenda.getNome());
        values.put("localidade", fazenda.getLocalidade());
        values.put("longitude", fazenda.getLongitude());
        values.put("latitude", fazenda.getLatitude());
        values.put("espacoparaCria", fazenda.getEspacoparaCria());
        values.put("municipio", fazenda.getmunicipio());
        //values.put("municipioId", fazenda.getMunicipioId());

        long registrafazenda = db.insert(DatabaseOpenHelper.TABLE_FAZENDA, null, values);

        return true;
    }

    public int insertCopy(Fazenda fazenda){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_NOME, fazenda.getNome());
        values.put(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LOCALIDADE, fazenda.getLocalidade());
        values.put(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LATITUDE, fazenda.getLatitude());
        values.put(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LONGITUDE, fazenda.getLongitude());
        
        int idInsert = (int) database.insert(DatabaseOpenHelper.TABLE_FAZENDA, null, values);
        if( idInsert != -1){
            return idInsert;
        }
        return -1;
    }

    public boolean update(Fazenda fazenda, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_ID, fazenda.getId());
        values.put(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_NOME, fazenda.getNome());
        values.put(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LOCALIDADE, fazenda.getLocalidade());
        values.put(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LATITUDE, fazenda.getLatitude());
        values.put(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LONGITUDE, fazenda.getLongitude());
        

        if(database.update(DatabaseOpenHelper.TABLE_FAZENDA, values, DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }



    public boolean updateIsFavorite(Fazenda fazenda) {
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_ID, fazenda.getNome());

        if(database.update(DatabaseOpenHelper.TABLE_FAZENDA, values, DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_ID + " = '" + fazenda.getId() + "'", null) == -1){
            return false;
        }

        return true;
    }


    public void delete(int codigo){
        database.delete(DatabaseOpenHelper.TABLE_FAZENDA, DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_ID + " = '" + codigo + "'", null);
    }
    /**
     * Retorna todos os itens cadastrados.
     */

    public ArrayAdapter<String> buscafazendas(Context context){

        ArrayAdapter<String>adpfazendas = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1);

        SQLiteDatabase db = helper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM tb_fazenda", null);

        if(cursor.getCount() > 0){
            cursor.moveToFirst();

            do {


                String nome = cursor.getString(1);
                String localidade = cursor.getString(2);
                String municipio = cursor.getString(3);
                String espacoparaCria = cursor.getString(4);

                adpfazendas.add(nome);
                adpfazendas.add(localidade);
                adpfazendas.add(municipio);
                adpfazendas.add(espacoparaCria);


            }while (cursor.moveToNext());
        }

        return adpfazendas;

    }

    public Fazenda getFazenda(int codigo){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_FAZENDA, TABLE_FAZENDA, DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_ID + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        Fazenda fazenda = null;
        if(!cursor.isAfterLast()){
            fazenda = cursorForItem(cursor);
        }

        cursor.close();
        return fazenda;
    }

    public Fazenda cursorForItem(Cursor cursor){
        Fazenda fazenda = new Fazenda();

        fazenda.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_ID)));
        fazenda.setNome(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_NOME)));
        fazenda.setLocalidade(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LOCALIDADE)));
        fazenda.setLatitude(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LATITUDE)));
        fazenda.setLongitude(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_LONGITUDE)));
        fazenda.setMunicipioId(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_FAZENDA_COLUMN_MUNICIPIO)));

        return fazenda;
    }

}
