package dao.modelDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;

import dao.helper.DatabaseOpenHelper;
import model.Potreiro;

/**
 * Created by mateus on 24/11/17.
 */
public class PotreiroDAO {

    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_POTREIRO_COLUMNS[] = {
            DatabaseOpenHelper.TABLE_POTREIRO_COLUMN_ID,
            DatabaseOpenHelper.TABLE_POTREIRO_COLUMN_NOME,
            DatabaseOpenHelper.TABLE_POTREIRO_COLUMN_TAMANHOPOTREIRO,
    };

    private Context mContext;


    public PotreiroDAO(Context context) {
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close() {
        helper.close();
    }

    public void salva(Potreiro potreiro) {
        /**
         * Se o ID do item é nulo é porque ele ainda não existe no banco de
         * dados, logo subentende-se que queremos adicionar o item no banco de
         * dados. Sendo assim, chamaremos o método adiciona() já definido no
         * DAO.
         */

        Potreiro potreiros = getPotreiro(potreiro.getId());

        if (potreiro == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(potreiro);
            /**
             * Caso o item possua um ID é porque ele já existe no banco de
             * dados, logo subentende-se que queremos alterar seus dados no
             * banco de dados. Sendo assim, chamaremos o método atualiza() já
             * definido no DAO.
             */
        } else {
            update(potreiro, potreiro.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }
    }

    public boolean update(Potreiro potreiro, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_POTREIRO_COLUMN_TAMANHOPOTREIRO, potreiro.getTamanhopotreiro());

        if(database.update(DatabaseOpenHelper.TABLE_POTREIRO, values, DatabaseOpenHelper.TABLE_POTREIRO_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }


    public boolean insert(Potreiro potreiro) {

        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        //Item
        values.put("_id", potreiro.getId());
        values.put("nomepotreiro", potreiro.getNomePotreiro());
        values.put("tamanhopotreiro", potreiro.getTamanhopotreiro());


        long potreiroinserir = db.insert(DatabaseOpenHelper.TABLE_POTREIRO, null, values);


        // if(database.insert(DatabaseOpenHelper.TABLE_USUARIO, null, values) == -1){
        //   return false;
        //}
        return true;
    }

    public Potreiro getPotreiro(int codigo) {
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_POTREIRO, TABLE_POTREIRO_COLUMNS, DatabaseOpenHelper.TABLE_POTREIRO_COLUMN_ID + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        Potreiro potreiro = null;
        if (!cursor.isAfterLast()) {
            potreiro = cursorForItem(cursor);
        }

        cursor.close();
        return potreiro;

    }
    public Potreiro cursorForItem(Cursor cursor) {
        Potreiro potreiro = new Potreiro();

        potreiro.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_POTREIRO_COLUMN_ID)));
        potreiro.setNomePotreiro(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_POTREIRO_COLUMN_NOME)));
        potreiro.setTamanhopotreiro(cursor.getString(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_POTREIRO_COLUMN_TAMANHOPOTREIRO)));

        return potreiro;
    }
}




