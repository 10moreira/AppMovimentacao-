package dao.modelDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.ArrayAdapter;

import java.sql.SQLException;

import dao.helper.DatabaseOpenHelper;
import model.CategoriaAnimal;
import model.Movimento;

/**
 * Created by mateus on 30/10/17.
 */
public class MovimentoDAO {

    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_MOVIMENTO_COLUMNS[] = {
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_DATAMOVIMENTO,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_QUANTIDADE,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_DESCRICAO,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_TIPO,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ORIGEM,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_DESTINO
    };

    private Context mContext;


    public MovimentoDAO(Context context){
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close(){
        helper.close();
    }

    public void salva(Movimento movimento) {
        /**
         * Se o ID do item é nulo é porque ele ainda não existe no banco de
         * dados, logo subentende-se que queremos adicionar o item no banco de
         * dados. Sendo assim, chamaremos o método adiciona() já definido no
         * DAO.
         */

        Movimento movimentol = getMovimento(movimento.getId());

        if ( movimento == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(movimento);
            /**
             * Caso o item possua um ID é porque ele já existe no banco de
             * dados, logo subentende-se que queremos alterar seus dados no
             * banco de dados. Sendo assim, chamaremos o método atualiza() já
             * definido no DAO.
             */
        } else {
            update(movimento, movimento.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }
    }

    public Movimento getMovimento(int codigo){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_MOVIMENTO, TABLE_MOVIMENTO_COLUMNS, DatabaseOpenHelper.TABLE_MOVIMENTO + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        Movimento movimento = null;
        if(!cursor.isAfterLast()){
            movimento = cursorForItem(cursor);
        }

        cursor.close();
        return movimento;
    }


    public boolean insert(Movimento movimento){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        //Item

        values.put("_id", movimento.getId());
        values.put("datamovimento", movimento.getData_movimento());
        values.put("quantidade", movimento.getQuantidade());
        values.put("descricao", movimento.getDescricao());
        values.put("tipo",movimento.getTipo());
        values.put("origem", movimento.getOrigem());
        values.put("destino", movimento.getDestino());
           CategoriaAnimal categoriaanimal = new CategoriaAnimal();
                values.put("_id", categoriaanimal.getId());


        long realizamovimento = db.insert(DatabaseOpenHelper.TABLE_MOVIMENTO, null, values);

        return true;

    }

    public int insertCopy(Movimento movimento){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_QUANTIDADE, movimento.getQuantidade());

        int idInsert = (int) database.insert(DatabaseOpenHelper.TABLE_MOVIMENTO, null, values);
        if( idInsert != -1){
            return idInsert;
        }
        return -1;
    }

    public boolean update(Movimento movimento, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID, movimento.getId());
        values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_QUANTIDADE, movimento.getQuantidade());

        if(database.update(DatabaseOpenHelper.TABLE_MOVIMENTO, values, DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }

    public boolean updateIsFavorite(Movimento movimento) {
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID, movimento.getId());

        if(database.update(DatabaseOpenHelper.TABLE_MOVIMENTO, values, DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID + " = '" + movimento.getId() + "'", null) == -1){
            return false;
        }

        return true;
    }


    public void delete(int codigo){
        database.delete(DatabaseOpenHelper.TABLE_MOVIMENTO, DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID + " = '" + codigo + "'", null);
    }
    /**
     * Retorna todos os itens cadastrados.
     */

    /*
    public Listamovimentos(SQLiteDatabase database){
        this.database = database;
    }
*/
    public ArrayAdapter<String> buscamovimentos(Context context){

        ArrayAdapter<String>adpmovimentos = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1);

        SQLiteDatabase db = helper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM tb_movimento", null);

        if(cursor.getCount() > 0){
            cursor.moveToFirst();

            do {

                String datamovimento = cursor.getString(1);
                String quantidade = cursor.getString(2);
                String destino = cursor.getString(3);
                String tipo = cursor.getString(4);
                String descricao = cursor.getString(5);

                adpmovimentos.add(datamovimento);
                adpmovimentos.add(quantidade);
                adpmovimentos.add(destino);
                adpmovimentos.add(tipo);
                adpmovimentos.add(descricao);

            }while (cursor.moveToNext());
        }

        return adpmovimentos;

    }



    public Movimento cursorForItem(Cursor cursor){
        Movimento movimento = new Movimento();

        movimento.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID)));

        return movimento;
    }
}
