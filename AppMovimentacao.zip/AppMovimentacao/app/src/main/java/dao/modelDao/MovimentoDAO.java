package dao.modelDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.helper.DatabaseOpenHelper;
import model.Movimento;

/**
 * Created by mateus on 30/10/17.
 */
public class MovimentoDAO {

    protected SQLiteDatabase database;
    protected DatabaseOpenHelper helper;


    protected static final String TABLE_MOVIMENTO_COLUMNS[] = {
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_DATAMOVIMENTO,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_QUANTIDADE,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_FAZENDA,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_GENEROANIMAL,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ORIGEMDESTINO,
            DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_USUARIO,
    };

    private Context mContext;


    public MovimentoDAO(Context context){
        helper = new DatabaseOpenHelper(context);
        mContext = context;
    }

    public void open() throws SQLException {
        database = helper.getWritableDatabase();
    }

    public void close(){
        helper.close();
    }

    public void salva(Movimento movimento) {
        /**
         * Se o ID do item é nulo é porque ele ainda não existe no banco de
         * dados, logo subentende-se que queremos adicionar o item no banco de
         * dados. Sendo assim, chamaremos o método adiciona() já definido no
         * DAO.
         */

        Movimento movimentol = getMovimento(movimento.getId());

        if ( movimento == null) {

            //Log.e("TAG","NÃO EXISTE. CRIA UM NOVO!");
            insert(movimento);
            /**
             * Caso o item possua um ID é porque ele já existe no banco de
             * dados, logo subentende-se que queremos alterar seus dados no
             * banco de dados. Sendo assim, chamaremos o método atualiza() já
             * definido no DAO.
             */
        } else {
            update(movimento, movimento.getId());
            //Log.e("TAG","EXISTE. ATUALIZA O EXISTENTE!");
        }
    }
    public boolean insert(Movimento movimento){
        ContentValues values = new ContentValues();
        //Item
        //values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_DATAMOVIMENTO, movimento.getData_movimento());
        values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_QUANTIDADE, movimento.getQuantidade());

        if(database.insert(DatabaseOpenHelper.TABLE_MOVIMENTO, null, values) == -1){
            return false;
        }
        return true;
    }

    public int insertCopy(Movimento movimento){
        ContentValues values = new ContentValues();
        //Item
        //values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_DATAMOVIMENTO, movimento.getData_movimento());
        values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_QUANTIDADE, movimento.getQuantidade());


        int idInsert = (int) database.insert(DatabaseOpenHelper.TABLE_MOVIMENTO, null, values);
        if( idInsert != -1){
            return idInsert;
        }
        return -1;
    }

    public boolean update(Movimento movimento, int codigo){
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID, movimento.getId());
        //values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_DATAMOVIMENTO, movimento.getData_movimento());
        values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_QUANTIDADE, movimento.getQuantidade());

        if(database.update(DatabaseOpenHelper.TABLE_MOVIMENTO, values, DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID + " = '" + codigo + "'", null) == -1){
            return false;
        }
        return true;
    }



    public boolean updateIsFavorite(Movimento movimento) {
        ContentValues values = new ContentValues();
        //Item
        values.put(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID, movimento.getId());

        if(database.update(DatabaseOpenHelper.TABLE_MOVIMENTO, values, DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID + " = '" + movimento.getId() + "'", null) == -1){
            return false;
        }

        return true;
    }


    public void delete(int codigo){
        database.delete(DatabaseOpenHelper.TABLE_MOVIMENTO, DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID + " = '" + codigo + "'", null);
    }
    /**
     * Retorna todos os itens cadastrados.
     */
    public List<Movimento> getAllMovimento(){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_MOVIMENTO, TABLE_MOVIMENTO_COLUMNS, null, null, null, null, DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_DATAMOVIMENTO + " ASC; ");
        cursor.moveToFirst();

        List<Movimento> movimento = new ArrayList<Movimento>();
        while(!cursor.isAfterLast()){
            movimento.add(cursorForItem(cursor));
            cursor.moveToNext();
        }
        cursor.close();
        return movimento;
    }

    public Movimento getMovimento(int codigo){
        Cursor cursor = database.query(DatabaseOpenHelper.TABLE_MOVIMENTO, TABLE_MOVIMENTO_COLUMNS, DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID + " = '" + codigo + "'", null, null, null, null);
        cursor.moveToFirst();

        Movimento movimento = null;
        if(!cursor.isAfterLast()){
            movimento = cursorForItem(cursor);
        }

        cursor.close();
        return movimento;
    }

    public Movimento cursorForItem(Cursor cursor){
        Movimento movimento = new Movimento();

        movimento.setId(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_ID)));
        //movimento.setData_movimento(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_DATAMOVIMENTO)));
        movimento.setQuantidade(cursor.getInt(cursor.getColumnIndex(DatabaseOpenHelper.TABLE_MOVIMENTO_COLUMN_QUANTIDADE)));

        return movimento;
    }


}
