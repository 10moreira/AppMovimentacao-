package dao.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by mateus on 23/10/17.
 */

public class DatabaseOpenHelper extends SQLiteOpenHelper {
    /**
     * Contexto da Classe
     */
    private Context mContext;

    /**
     * Versao do banco de dados
     */
    public static final int DATA_VERSION_ID = 1;

    /**
     * Nome do banco de dados
     */
    public static final String DATABASE_NAME = "DBappMovimento.sqlite";

    /**
     * Nome das tabelas.
     */
    public static final String TABLE_CATEGORIAANIMAL = "tb_categoriaAnimal";
    public static final String TABLE_ESTOQUE = "tb_estoque";
    public static final String TABLE_FAZENDA = "tb_fazenda";
    public static final String TABLE_GENEROANIMAL = "tb_generoAnimal";
    public static final String TABLE_MOVIMENTO = "tb_movimento";
    public static final String TABLE_MUNICIPIO = "tb_municipio";
    public static final String TABLE_ORIGEMDESTINO = "tb_origemDestino";
    public static final String TABLE_TIPOUSUARIO = "tb_tipousuario";
    public static final String TABLE_USUARIO = "tb_usuario";



    public static final String
            TABLE_CATEGORIAANIMAL_COLUMN_ID = "id",
            TABLE_CATGORIAANIMAL_COLUMN_NOME = "nome",
            TABLE_CATEGORIAANIMAL_COLUMN_MESESINICIAIS = "mesesiniciais",
            TABLE_CATEGORIAANIMAL_COLUMN_MESESFINAIS = "mesesfinais";



    public static final String SQL_CREATE_TABLE_CATEGORIAANIMAL = "CREATE TABLE " + TABLE_CATEGORIAANIMAL + " ( "

            + TABLE_CATEGORIAANIMAL_COLUMN_ID + "  INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TABLE_CATGORIAANIMAL_COLUMN_NOME + " TEXT NOT NULL, "
            + TABLE_CATEGORIAANIMAL_COLUMN_MESESINICIAIS + " TEXT NOT NULL, "
            + TABLE_CATEGORIAANIMAL_COLUMN_MESESFINAIS + " TEXT  NOT NULL) ";

    /**
     * Campos da tabela de Estoque.
     */
    public static final String
            TABLE_ESTOQUE_COLUMN_ID = "id",
            TABLE_ESTOQUE_COLUMN_SALDO = "saldo",
            TABLE_ESTOQUE_COLUMN_ORIGEMDESTINO = "origemdestino",
            TABLE_ESTOQUE_COLUMN_GENEROANIMAL = "generoAnimal",
            TABLE_ESTOQUE_COLUMN_FAZENDA = "fazenda";
    /**
     * String SQL para a criacao da tabela de itens.
     */
    public static final String SQL_CREATE_TABLE_ESTOQUE = "CREATE TABLE " + TABLE_ESTOQUE + " ( "

            + TABLE_ESTOQUE_COLUMN_ID + "  INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TABLE_ESTOQUE_COLUMN_SALDO + " TEXT NOT NULL, "
            + TABLE_ESTOQUE_COLUMN_ORIGEMDESTINO + " TEXT NOT NULL, "
            + TABLE_ESTOQUE_COLUMN_GENEROANIMAL + " TEXT  NOT NULL, "
            + TABLE_ESTOQUE_COLUMN_FAZENDA + " TEXT  NOT NULL) ";


    public static final String
        TABLE_FAZENDA_COLUMN_ID = "id",
        TABLE_FAZENDA_COLUMN_NOME = "nome",
        TABLE_FAZENDA_COLUMN_LOCALIDADE = "localidade",
        TABLE_FAZENDA_COLUMN_LATITUDE = "latitude",
        TABLE_FAZENDA_COLUMN_LONGITUDE = "longitude";




    public static final String SQL_CREATE_TABLE_FAZENDA = "CREATE TABLE" + TABLE_FAZENDA + " ( "

            + TABLE_FAZENDA_COLUMN_ID + "  INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TABLE_FAZENDA_COLUMN_NOME + " TEXT NOT NULL, "
            + TABLE_FAZENDA_COLUMN_LOCALIDADE + " TEXT NOT NULL, "
            + TABLE_FAZENDA_COLUMN_LATITUDE + " TEXT  NOT NULL, "
            + TABLE_FAZENDA_COLUMN_LONGITUDE + " TEXT  NOT NULL) ";



    public static final String
            TABLE_GENEROANIMAL_COLUMN_ID = "id",
            TABLE_GENEROANIMAL_COLUMN_SEXO = "sexo",
            TABLE_GENEROANIMAL_COLUMN_DESCRICAO = "descricao",
            TABLE_GENEROANIMAL_COLUMN_CATEGORIA_ANIMAL = "categoria_animal";



    public static final String SQL_CREATE_TABLE_GENEROANIMAL = "CREATE TABLE" + TABLE_GENEROANIMAL + " ( "

            + TABLE_GENEROANIMAL_COLUMN_ID + "  INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TABLE_GENEROANIMAL_COLUMN_SEXO + " TEXT NOT NULL, "
            + TABLE_GENEROANIMAL_COLUMN_DESCRICAO + " TEXT NOT NULL, "
            + TABLE_GENEROANIMAL_COLUMN_CATEGORIA_ANIMAL + " TEXT  NOT NULL) ";


    public static final String
            TABLE_MOVIMENTO_COLUMN_ID = "id",
            TABLE_MOVIMENTO_COLUMN_DATAMOVIMENTO = "datamovimento",
            TABLE_MOVIMENTO_COLUMN_QUANTIDADE = "quantidade",
            TABLE_MOVIMENTO_COLUMN_FAZENDA = "fazenda",
            TABLE_MOVIMENTO_COLUMN_GENEROANIMAL = "generoanimal",
            TABLE_MOVIMENTO_COLUMN_ORIGEMDESTINO = "origemdestino",
            TABLE_MOVIMENTO_COLUMN_USUARIO = "usuario";


    public static final String SQL_CREATE_TABLE_MOVIMENTO = "CREATE TABLE" + TABLE_MOVIMENTO + " ( "

            + TABLE_MOVIMENTO_COLUMN_ID + "  INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TABLE_MOVIMENTO_COLUMN_DATAMOVIMENTO + " TEXT NOT NULL, "
            + TABLE_MOVIMENTO_COLUMN_QUANTIDADE + " TEXT NOT NULL, "
            + TABLE_MOVIMENTO_COLUMN_FAZENDA + " TEXT  NOT NULL, "
            + TABLE_MOVIMENTO_COLUMN_GENEROANIMAL + "TEXT  NOT NULL, "
            + TABLE_MOVIMENTO_COLUMN_ORIGEMDESTINO + "TEXT  NOT NULL, "
            +TABLE_MOVIMENTO_COLUMN_USUARIO + "TEXT NOT NULL) ";



    public static final String
      TABLE_MUNICIPIO_COLUMN_ID = "id",
      TABLE_MUNICIPIO_COLUMN_NOME = "nome";


    public static final String SQL_CREATE_TABLE_MUNICIPIO = "CREATE TABLE" + TABLE_MUNICIPIO + " ( "

            + TABLE_MUNICIPIO_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TABLE_MUNICIPIO_COLUMN_NOME + " TEXT NOT NULL) ";



    public static final String
            TABLE_ORIGEMDESTINO_COLUMN_ID = "id",
            TABLE_ORIGEMDESTINO_COLUMN_DESTINO = "destino",
            TABLE_ORIGEMDESTINO_COLUMN_ORIGEM = "origem",
            TABLE_ORIGEMDESTINO_COLUMN_DECRICAO = "descricao",
            TABLE_ORIGEMDESTINO_COLUMN_TIPO = "tipo",
            TABLE_ORIGEMDESTINO_COLUMN_FAZENDA = "fazenda";



    public static final String SQL_CREATE_TABLE_ORIGEMDESTINO = "CREATE TABLE" + TABLE_ORIGEMDESTINO + " ( "

            + TABLE_ORIGEMDESTINO_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TABLE_ORIGEMDESTINO_COLUMN_DESTINO + " TEXT NOT NULL, "
            + TABLE_ORIGEMDESTINO_COLUMN_ORIGEM + " TEXT NOT NULL, "
            + TABLE_ORIGEMDESTINO_COLUMN_DECRICAO + "TEXT NOT NULL, "
            + TABLE_ORIGEMDESTINO_COLUMN_TIPO + "TEXT NOT NULL, "
            + TABLE_ORIGEMDESTINO_COLUMN_FAZENDA + "TEXT NOT NULL) ";


    public static final String
            TABLE_TIPOUSUARIO_COLUMN_ID = "id",
            TABLE_TIPOUSUARIO_COLUMN_TIPO = "tipo",
            TABLE_TIPOUSUARIO_COLUMN_NOME = "nome";



    public static final String SQL_CREATE_TABLE_TIPOUSUARIO = "CREATE TABLE" + TABLE_TIPOUSUARIO + " ( "

            + TABLE_TIPOUSUARIO_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TABLE_TIPOUSUARIO_COLUMN_TIPO + " TEXT NOT NULL, "
            + TABLE_TIPOUSUARIO_COLUMN_NOME + " TEXT NOT NULL) ";


    public static final String
            TABLE_USUARIO_COLUMN_ID = "id",
            TABLE_USUARIO_COLUMN_NOME = "nome",
            TABLE_USUARIO_COLUN_EMAIL = "email",
            TABLE_USUARIO_COLUMN_FONE_DDI = "ddi",
            TABLE_USUARIO_COLUMN_FONE_AREA = "fonearea",
            TABLE_USUARIO_COLUMN_FONE = "fone",
            TABLE_USUARIO_COLUMN_TIPO = "tipo";


    public static final String SQL_CREATE_TABLE_USUARIO = "CREATE TABLE" + TABLE_USUARIO + " ( "

            + TABLE_USUARIO_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TABLE_USUARIO_COLUMN_NOME + " TEXT NOT NULL, "
            + TABLE_USUARIO_COLUN_EMAIL + " TEXT NOT NULL, "
            + TABLE_USUARIO_COLUMN_FONE_DDI + "TEXT NOT NULL,"
            + TABLE_USUARIO_COLUMN_FONE_AREA + "TEXT NOT NULL,"
            + TABLE_USUARIO_COLUMN_FONE + "TEXT NOT NULL,"
            + TABLE_USUARIO_COLUMN_TIPO + "TEXT NOT NULL";


    /**
     * Construtor da classe.
     */
    public DatabaseOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATA_VERSION_ID);
        mContext = context;
    }

    /**
     * Esta funcao eh chamada para a criacao da base de dados, no caso de nao existir.
     */
    @Override
    public void onCreate(SQLiteDatabase database) {
		/*
		 * Executa a criacao de cada uma das tabela com base nas strings SQL definidas.
		 */

        database.execSQL(SQL_CREATE_TABLE_CATEGORIAANIMAL);
        Log.e("TABLE:", SQL_CREATE_TABLE_CATEGORIAANIMAL);

        database.execSQL(SQL_CREATE_TABLE_FAZENDA);
        Log.e("TABLE:", SQL_CREATE_TABLE_FAZENDA);

        database.execSQL(SQL_CREATE_TABLE_GENEROANIMAL);
        Log.e("TABLE:", SQL_CREATE_TABLE_GENEROANIMAL);

        database.execSQL(SQL_CREATE_TABLE_MOVIMENTO);
        Log.e("TABLE:", SQL_CREATE_TABLE_MOVIMENTO);

        database.execSQL(SQL_CREATE_TABLE_ESTOQUE);
        Log.e("TABLE:", SQL_CREATE_TABLE_ESTOQUE);


    }

    /**
     * Esta funcao eh chamada no caso de a versao de ID mudar, para alterar a estrutura ou dropar os dados
     */
    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
		/*
		 * Apaga a tabela atual caso haja atualizacoes.
		 */
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORIAANIMAL);
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_FAZENDA);
        database.execSQL("DROP TABLE IF EXISTS"  + TABLE_GENEROANIMAL);
        database.execSQL("DROP TABLE IF EXISTS" + TABLE_MOVIMENTO);
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_ESTOQUE);

        /**
         * Apos apagar a tabela do banco de dados eh necessario cria-la novamente.
         */
        onCreate(database);
    }


}